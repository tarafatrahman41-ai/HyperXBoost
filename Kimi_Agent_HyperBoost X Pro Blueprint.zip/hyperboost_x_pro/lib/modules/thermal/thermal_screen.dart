import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/providers/app_providers.dart';
import '../../core/models/telemetry_models.dart';

/// Thermal monitoring and throttling detection screen
class ThermalScreen extends ConsumerWidget {
  const ThermalScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final zones = ref.watch(sortedThermalZonesProvider);
    final telemetry = ref.watch(currentTelemetryProvider);
    final isThrottling = telemetry.thermalThrottling;

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Throttling alert
          if (isThrottling)
            _buildThrottlingAlert(context),
          if (isThrottling)
            const SizedBox(height: 20),
          
          // Overall temperature summary
          _buildTemperatureSummary(context, zones, telemetry.batteryTempC),
          const SizedBox(height: 20),
          
          // Battery temperature
          _buildBatteryTempCard(context, telemetry.batteryTempC),
          const SizedBox(height: 20),
          
          // Thermal zones list
          _buildZonesList(context, zones),
          const SizedBox(height: 20),
          
          // Throttling info
          _buildThrottlingInfo(context),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _buildThrottlingAlert(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFFFF1744).withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: const Color(0xFFFF1744).withOpacity(0.5),
          width: 1.5,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFFFF1744).withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.warning_amber, color: Color(0xFFFF1744), size: 28),
          ),
          const SizedBox(width: 16),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'THERMAL THROTTLING DETECTED',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFFFF1744),
                    letterSpacing: 0.5,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Device is reducing performance to manage heat. Consider closing background apps or improving ventilation.',
                  style: TextStyle(
                    fontSize: 12,
                    color: Color(0xFFCCCCCC),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTemperatureSummary(BuildContext context, List<ThermalZone> zones, double batteryTemp) {
    final hottest = zones.isNotEmpty ? zones.first.temperatureC : 0.0;
    final allTemps = zones.map((z) => z.temperatureC).toList();
    final avgTemp = allTemps.isNotEmpty ? allTemps.reduce((a, b) => a + b) / allTemps.length : 0.0;
    
    Color statusColor;
    String status;
    if (hottest > 85) {
      statusColor = const Color(0xFFFF1744);
      status = 'CRITICAL';
    } else if (hottest > 70) {
      statusColor = const Color(0xFFFFAB00);
      status = 'ELEVATED';
    } else if (hottest > 50) {
      statusColor = const Color(0xFF00E5FF);
      status = 'MODERATE';
    } else {
      statusColor = const Color(0xFF76FF03);
      status = 'NORMAL';
    }

    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF121212),
            const Color(0xFF0A0A0A),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: statusColor.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Text(
            'THERMAL STATUS',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: const Color(0xFF808080),
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            decoration: BoxDecoration(
              color: statusColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              status,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: statusColor,
                letterSpacing: 3,
              ),
            ),
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildTempStat('HOTTEST', hottest, statusColor),
              _buildTempStat('AVERAGE', avgTemp, const Color(0xFF00E5FF)),
              _buildTempStat('ZONES', zones.length.toDouble(), const Color(0xFF808080), ''),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTempStat(String label, double value, Color color, [String unit = '°C']) {
    return Column(
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w600,
            color: Color(0xFF808080),
            letterSpacing: 1.5,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          unit.isEmpty ? value.toInt().toString() : '${value.toStringAsFixed(1)}$unit',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.w700,
            color: color,
            fontFamily: 'JetBrainsMono',
          ),
        ),
      ],
    );
  }

  Widget _buildBatteryTempCard(BuildContext context, double batteryTemp) {
    final color = batteryTemp > 45 ? const Color(0xFFFF1744)
        : batteryTemp > 38 ? const Color(0xFFFFAB00)
        : const Color(0xFF76FF03);

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Row(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.battery_full,
              color: color,
              size: 28,
            ),
          ),
          const SizedBox(width: 20),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'BATTERY TEMPERATURE',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF808080),
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  '${batteryTemp.toStringAsFixed(1)}°C',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w700,
                    color: color,
                    fontFamily: 'JetBrainsMono',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildZonesList(BuildContext context, List<ThermalZone> zones) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'THERMAL ZONES',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF808080),
                  letterSpacing: 1.5,
                ),
              ),
              Text(
                '${zones.length} detected',
                style: const TextStyle(
                  fontSize: 11,
                  color: Color(0xFF606060),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ...zones.take(12).map((zone) => _buildZoneRow(zone)),
        ],
      ),
    );
  }

  Widget _buildZoneRow(ThermalZone zone) {
    final temp = zone.temperatureC;
    Color color;
    if (temp > 80) color = const Color(0xFFFF1744);
    else if (temp > 60) color = const Color(0xFFFFAB00);
    else if (temp > 40) color = const Color(0xFF00E5FF);
    else color = const Color(0xFF76FF03);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              zone.name,
              style: const TextStyle(
                fontSize: 13,
                color: Color(0xFFCCCCCC),
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          const SizedBox(width: 12),
          Text(
            '${temp.toStringAsFixed(1)}°C',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: color,
              fontFamily: 'JetBrainsMono',
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 60,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(2),
              child: LinearProgressIndicator(
                value: (temp / 100).clamp(0, 1),
                backgroundColor: const Color(0xFF1E1E1E),
                valueColor: AlwaysStoppedAnimation<Color>(color),
                minHeight: 4,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildThrottlingInfo(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'THROTTLING DETECTION',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: Color(0xFF808080),
              letterSpacing: 1.5,
            ),
          ),
          SizedBox(height: 16),
          _InfoRow(
            icon: Icons.thermostat,
            title: 'CPU Thermal Throttle',
            desc: 'Triggers when CPU zone > 85°C with frequency reduction',
          ),
          SizedBox(height: 12),
          _InfoRow(
            icon: Icons.graphic_eq,
            title: 'GPU Thermal Throttle',
            desc: 'Triggers when GPU zone > 80°C with frequency reduction',
          ),
          SizedBox(height: 12),
          _InfoRow(
            icon: Icons.speed,
            title: 'Performance Impact',
            desc: 'Monitored by correlating temperature spikes with frequency drops',
          ),
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final String desc;

  const _InfoRow({required this.icon, required this.title, required this.desc});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: const Color(0xFF00E5FF), size: 18),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFFFFFFFF),
                ),
              ),
              const SizedBox(height: 2),
              Text(
                desc,
                style: const TextStyle(
                  fontSize: 12,
                  color: Color(0xFF808080),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
