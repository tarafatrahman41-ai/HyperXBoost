import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/providers/app_providers.dart';

/// Application settings screen
class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(appSettingsProvider);

    return Scaffold(
      backgroundColor: const Color(0xFF000000),
      appBar: AppBar(
        backgroundColor: const Color(0xFF000000),
        title: const Text('Settings'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader('Telemetry'),
            _buildPollingIntervalSetting(context, ref, settings),
            const SizedBox(height: 8),
            _buildSwitchTile(
              'Frame Tracking',
              'Monitor frame rate via Choreographer',
              settings.frameTrackingEnabled,
              (value) => ref.read(appSettingsProvider.notifier).state = 
                  settings.copyWith(frameTrackingEnabled: value),
            ),
            const SizedBox(height: 24),
            
            _buildSectionHeader('Overlay'),
            _buildSwitchTile(
              'Floating Overlay',
              'Show telemetry overlay on top of games',
              settings.overlayEnabled,
              (value) => ref.read(appSettingsProvider.notifier).state = 
                  settings.copyWith(overlayEnabled: value),
            ),
            const SizedBox(height: 8),
            _buildOverlayRateSetting(context, ref, settings),
            const SizedBox(height: 24),
            
            _buildSectionHeader('Display'),
            _buildSwitchTile(
              'Show Decimal FPS',
              'Display FPS with one decimal place',
              settings.showDecimalFps,
              (value) => ref.read(appSettingsProvider.notifier).state = 
                  settings.copyWith(showDecimalFps: value),
            ),
            const SizedBox(height: 8),
            _buildRefreshRateSetting(context, ref, settings),
            const SizedBox(height: 24),
            
            _buildSectionHeader('About'),
            _buildAboutCard(context),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(
        title.toUpperCase(),
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w700,
          color: Color(0xFF00E5FF),
          letterSpacing: 2,
        ),
      ),
    );
  }

  Widget _buildPollingIntervalSetting(BuildContext context, WidgetRef ref, AppSettings settings) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Polling Interval',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFFFFFFFF),
                ),
              ),
              Text(
                '${settings.pollingIntervalMs}ms',
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF00E5FF),
                  fontFamily: 'JetBrainsMono',
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          const Text(
            'Lower interval = more accurate but higher CPU usage',
            style: TextStyle(fontSize: 11, color: Color(0xFF808080)),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _IntervalChip(
                label: '100ms',
                selected: settings.pollingIntervalMs == 100,
                onTap: () => ref.read(appSettingsProvider.notifier).state = 
                    settings.copyWith(pollingIntervalMs: 100),
              ),
              const SizedBox(width: 8),
              _IntervalChip(
                label: '500ms',
                selected: settings.pollingIntervalMs == 500,
                onTap: () => ref.read(appSettingsProvider.notifier).state = 
                    settings.copyWith(pollingIntervalMs: 500),
              ),
              const SizedBox(width: 8),
              _IntervalChip(
                label: '1000ms',
                selected: settings.pollingIntervalMs == 1000,
                onTap: () => ref.read(appSettingsProvider.notifier).state = 
                    settings.copyWith(pollingIntervalMs: 1000),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildOverlayRateSetting(BuildContext context, WidgetRef ref, AppSettings settings) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Overlay Update Rate',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFFFFFFFF),
                ),
              ),
              Text(
                '${settings.overlayUpdateRateMs}ms',
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF00E5FF),
                  fontFamily: 'JetBrainsMono',
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Slider(
            value: settings.overlayUpdateRateMs.toDouble(),
            min: 50,
            max: 500,
            divisions: 9,
            activeColor: const Color(0xFF00E5FF),
            inactiveColor: const Color(0xFF2A2A2A),
            onChanged: (value) {
              ref.read(appSettingsProvider.notifier).state = 
                  settings.copyWith(overlayUpdateRateMs: value.round());
            },
          ),
        ],
      ),
    );
  }

  Widget _buildRefreshRateSetting(BuildContext context, WidgetRef ref, AppSettings settings) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Target Refresh Rate',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: Color(0xFFFFFFFF),
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            'Set your device display refresh rate for frame-time calculations',
            style: TextStyle(fontSize: 11, color: Color(0xFF808080)),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _IntervalChip(
                label: '60Hz',
                selected: settings.targetRefreshRate == 60,
                onTap: () => ref.read(appSettingsProvider.notifier).state = 
                    settings.copyWith(targetRefreshRate: 60),
              ),
              const SizedBox(width: 8),
              _IntervalChip(
                label: '90Hz',
                selected: settings.targetRefreshRate == 90,
                onTap: () => ref.read(appSettingsProvider.notifier).state = 
                    settings.copyWith(targetRefreshRate: 90),
              ),
              const SizedBox(width: 8),
              _IntervalChip(
                label: '120Hz',
                selected: settings.targetRefreshRate == 120,
                onTap: () => ref.read(appSettingsProvider.notifier).state = 
                    settings.copyWith(targetRefreshRate: 120),
              ),
              const SizedBox(width: 8),
              _IntervalChip(
                label: '144Hz',
                selected: settings.targetRefreshRate == 144,
                onTap: () => ref.read(appSettingsProvider.notifier).state = 
                    settings.copyWith(targetRefreshRate: 144),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSwitchTile(String title, String subtitle, bool value, ValueChanged<bool> onChanged) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFFFFFFFF),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: const TextStyle(
                    fontSize: 11,
                    color: Color(0xFF808080),
                  ),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeColor: const Color(0xFF00E5FF),
            activeTrackColor: const Color(0xFF00E5FF).withOpacity(0.3),
            inactiveTrackColor: const Color(0xFF2A2A2A),
          ),
        ],
      ),
    );
  }

  Widget _buildAboutCard(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.info_outline, color: Color(0xFF00E5FF), size: 20),
              SizedBox(width: 12),
              Text(
                'HyperBoost X Pro',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFFFFFFFF),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          const Text(
            'Real-Time Gaming Performance & Telemetry Platform',
            style: TextStyle(
              fontSize: 13,
              color: Color(0xFF808080),
            ),
          ),
          const SizedBox(height: 20),
          _buildInfoRow('Version', '1.0.0 (Build 100)'),
          _buildInfoRow('Platform', 'Android (API 26+)'),
          _buildInfoRow('Architecture', 'ARM64 / ARMv7'),
          _buildInfoRow('NDK', 'r25b'),
          _buildInfoRow('Flutter', '3.22.0'),
          const SizedBox(height: 16),
          const Divider(color: Color(0xFF2A2A2A)),
          const SizedBox(height: 12),
          const Text(
            'All metrics are derived from genuine Android public APIs, /proc and /sys filesystems. No synthetic benchmarks or fabricated data.',
            style: TextStyle(
              fontSize: 11,
              color: Color(0xFF606060),
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(
              fontSize: 13,
              color: Color(0xFF808080),
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: Color(0xFFFFFFFF),
              fontFamily: 'JetBrainsMono',
            ),
          ),
        ],
      ),
    );
  }
}

class _IntervalChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _IntervalChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFF00E5FF) : const Color(0xFF1A1A1A),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: selected ? const Color(0xFF00E5FF) : const Color(0xFF2A2A2A),
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 12,
            fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
            color: selected ? const Color(0xFF000000) : const Color(0xFFCCCCCC),
            fontFamily: 'JetBrainsMono',
          ),
        ),
      ),
    );
  }
}
