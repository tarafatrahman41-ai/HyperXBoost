import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../core/providers/app_providers.dart';
import '../../core/models/telemetry_models.dart';

/// Hardware monitoring screen with CPU/GPU/Memory details
class HardwareScreen extends ConsumerWidget {
  const HardwareScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final telemetry = ref.watch(currentTelemetryProvider);
    final history = ref.watch(telemetryHistoryProvider);

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // CPU Section
          _buildCpuSection(context, telemetry.cpu, history),
          const SizedBox(height: 20),
          
          // GPU Section
          _buildGpuSection(context, telemetry.gpu),
          const SizedBox(height: 20),
          
          // Memory Section
          _buildMemorySection(context, telemetry.memory, history),
          const SizedBox(height: 20),
          
          // Device Info
          _buildDeviceInfoCard(context, ref),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _buildCpuSection(BuildContext context, CpuTelemetry cpu, List<TelemetrySnapshot> history) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  const Icon(Icons.memory, color: Color(0xFF00E5FF), size: 20),
                  const SizedBox(width: 10),
                  const Text(
                    'CPU',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFFFFFFFF),
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: _getLoadColor(cpu.loadPercent).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  '${cpu.loadPercent.toStringAsFixed(1)}%',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: _getLoadColor(cpu.loadPercent),
                    fontFamily: 'JetBrainsMono',
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          
          // CPU Load Chart
          if (history.length >= 2)
            SizedBox(
              height: 120,
              child: LineChart(
                LineChartData(
                  gridData: const FlGridData(show: false),
                  titlesData: const FlTitlesData(show: false),
                  borderData: FlBorderData(show: false),
                  minY: 0,
                  maxY: 100,
                  lineBarsData: [
                    LineChartBarData(
                      spots: history.asMap().entries.map((e) {
                        return FlSpot(e.key.toDouble(), e.value.cpu.loadPercent);
                      }).toList(),
                      isCurved: true,
                      color: const Color(0xFF00E5FF),
                      barWidth: 2,
                      dotData: const FlDotData(show: false),
                      belowBarData: BarAreaData(
                        show: true,
                        color: const Color(0xFF00E5FF).withOpacity(0.1),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          
          const SizedBox(height: 20),
          
          // Core Frequencies
          if (cpu.coreFrequenciesMhz.isNotEmpty) ...[
            const Text(
              'CORE FREQUENCIES',
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w600,
                color: Color(0xFF808080),
                letterSpacing: 1.5,
              ),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: cpu.coreFrequenciesMhz.asMap().entries.map((entry) {
                final freq = entry.value;
                final freqMhz = freq ~/ 1000;
                final isHigh = freqMhz > 2000;
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1A1A1A),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: isHigh ? const Color(0xFFFFAB00).withOpacity(0.3) : const Color(0xFF2A2A2A),
                    ),
                  ),
                  child: Column(
                    children: [
                      Text(
                        'CPU${entry.key}',
                        style: const TextStyle(
                          fontSize: 9,
                          color: Color(0xFF808080),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${freqMhz}MHz',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: isHigh ? const Color(0xFFFFAB00) : const Color(0xFF00E5FF),
                          fontFamily: 'JetBrainsMono',
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildGpuSection(BuildContext context, GpuTelemetry gpu) {
    if (!gpu.available || gpu.usagePercent < 0) {
      return _buildUnavailableSection('GPU', 'GPU telemetry unavailable on this device');
    }

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  const Icon(Icons.graphic_eq, color: Color(0xFF76FF03), size: 20),
                  const SizedBox(width: 10),
                  const Text(
                    'GPU',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFFFFFFFF),
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
              Text(
                gpu.vendorName,
                style: const TextStyle(
                  fontSize: 11,
                  color: Color(0xFF808080),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: _buildGpuStat('Usage', '${gpu.usagePercent}%', 
                    _getUsageColor(gpu.usagePercent)),
              ),
              Expanded(
                child: _buildGpuStat('Frequency', '${gpu.frequencyMhz}MHz', 
                    const Color(0xFF00E5FF)),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: gpu.usagePercent / 100.0,
              backgroundColor: const Color(0xFF1E1E1E),
              valueColor: AlwaysStoppedAnimation<Color>(_getUsageColor(gpu.usagePercent)),
              minHeight: 10,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMemorySection(BuildContext context, MemoryTelemetry memory, 
      List<TelemetrySnapshot> history) {
    final usedPercent = memory.usedPercent;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.storage, color: Color(0xFFFFAB00), size: 20),
              const SizedBox(width: 10),
              const Text(
                'MEMORY',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFFFFFFFF),
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          
          // Memory usage chart
          if (history.length >= 2)
            SizedBox(
              height: 100,
              child: LineChart(
                LineChartData(
                  gridData: const FlGridData(show: false),
                  titlesData: const FlTitlesData(show: false),
                  borderData: FlBorderData(show: false),
                  minY: 0,
                  maxY: 100,
                  lineBarsData: [
                    LineChartBarData(
                      spots: history.asMap().entries.map((e) {
                        return FlSpot(e.key.toDouble(), e.value.memory.usedPercent);
                      }).toList(),
                      isCurved: true,
                      color: const Color(0xFFFFAB00),
                      barWidth: 2,
                      dotData: const FlDotData(show: false),
                      belowBarData: BarAreaData(
                        show: true,
                        color: const Color(0xFFFFAB00).withOpacity(0.1),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          
          const SizedBox(height: 20),
          
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildMemDetail('Total', '${memory.totalMb}MB', const Color(0xFF00E5FF)),
              _buildMemDetail('Used', '${memory.usedMb}MB', const Color(0xFFFFAB00)),
              _buildMemDetail('Available', '${memory.availableMb}MB', const Color(0xFF76FF03)),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: usedPercent / 100.0,
              backgroundColor: const Color(0xFF1E1E1E),
              valueColor: AlwaysStoppedAnimation<Color>(
                usedPercent > 90 ? const Color(0xFFFF1744)
                    : usedPercent > 75 ? const Color(0xFFFFAB00)
                    : const Color(0xFF00E5FF)
              ),
              minHeight: 10,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDeviceInfoCard(BuildContext context, WidgetRef ref) {
    final deviceInfoAsync = ref.watch(deviceInfoProvider);
    
    return deviceInfoAsync.when(
      data: (info) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: const Color(0xFF121212),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFF2A2A2A)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.phone_android, color: Color(0xFF808080), size: 18),
                SizedBox(width: 10),
                Text(
                  'DEVICE INFO',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF808080),
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            _buildInfoRow('Brand', info['brand']?.toString() ?? 'Unknown'),
            _buildInfoRow('Model', info['model']?.toString() ?? 'Unknown'),
            _buildInfoRow('Device', info['device']?.toString() ?? 'Unknown'),
            _buildInfoRow('Android', 'API ${info['sdkInt']} (${info['androidVersion']})'),
            _buildInfoRow('Hardware', info['hardware']?.toString() ?? 'Unknown'),
            _buildInfoRow('ABIs', (info['supportedAbis'] as List<dynamic>?)?.join(', ') ?? 'Unknown'),
          ],
        ),
      ),
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (_, __) => const SizedBox.shrink(),
    );
  }

  Widget _buildGpuStat(String label, String value, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(fontSize: 11, color: Color(0xFF808080)),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.w700,
            color: color,
            fontFamily: 'JetBrainsMono',
          ),
        ),
      ],
    );
  }

  Widget _buildMemDetail(String label, String value, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(fontSize: 10, color: Color(0xFF808080), letterSpacing: 1),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: color,
            fontFamily: 'JetBrainsMono',
          ),
        ),
      ],
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(fontSize: 13, color: Color(0xFF808080)),
          ),
          Text(
            value,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: Color(0xFFFFFFFF),
              fontFamily: 'JetBrainsMono',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUnavailableSection(String label, String message) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: Color(0xFFFFFFFF),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            message,
            style: const TextStyle(fontSize: 13, color: Color(0xFF808080)),
          ),
        ],
      ),
    );
  }

  Color _getLoadColor(double load) {
    if (load > 80) return const Color(0xFFFF1744);
    if (load > 50) return const Color(0xFFFFAB00);
    return const Color(0xFF00E5FF);
  }

  Color _getUsageColor(int usage) {
    if (usage > 90) return const Color(0xFFFF1744);
    if (usage > 70) return const Color(0xFFFFAB00);
    return const Color(0xFF76FF03);
  }
}
