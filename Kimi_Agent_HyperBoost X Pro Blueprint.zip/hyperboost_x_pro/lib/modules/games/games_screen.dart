import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/providers/app_providers.dart';

/// Game library scanner and resource management screen
class GamesScreen extends ConsumerStatefulWidget {
  const GamesScreen({super.key});

  @override
  ConsumerState<GamesScreen> createState() => _GamesScreenState();
}

class _GamesScreenState extends ConsumerState<GamesScreen> {
  bool _isScanning = false;
  List<Map<String, dynamic>> _games = [];
  String _selectedCategory = 'All';
  
  final List<String> _categories = ['All', 'Shooter', 'MOBA', 'Racing', 'RPG', 'Sports', 'Puzzle', 'Strategy', 'Other'];

  @override
  void initState() {
    super.initState();
    _scanGames();
  }

  Future<void> _scanGames() async {
    setState(() => _isScanning = true);
    
    // Simulated game scan - in production, this would use platform channel
    // to call GameScanner.scanInstalledGames()
    await Future.delayed(const Duration(milliseconds: 800));
    
    setState(() {
      _games = [
        {'name': 'PUBG Mobile', 'package': 'com.tencent.ig', 'category': 'Shooter', 'size': '2.4 GB'},
        {'name': 'Call of Duty Mobile', 'package': 'com.activision.callofduty.shooter', 'category': 'Shooter', 'size': '3.1 GB'},
        {'name': 'Genshin Impact', 'package': 'com.miHoYo.GenshinImpact', 'category': 'RPG', 'size': '18.2 GB'},
        {'name': 'League of Legends Wild Rift', 'package': 'com.riotgames.league.wildrift', 'category': 'MOBA', 'size': '3.8 GB'},
        {'name': 'Asphalt 9', 'package': 'com.gameloft.android.ANMP.GloftA9HM', 'category': 'Racing', 'size': '2.9 GB'},
        {'name': 'Mobile Legends', 'package': 'com.moonton.mobilelegend', 'category': 'MOBA', 'size': '2.1 GB'},
        {'name': 'Honkai Star Rail', 'package': 'com.HoYoverse.hkrpgoversea', 'category': 'RPG', 'size': '12.5 GB'},
        {'name': 'Apex Legends Mobile', 'package': 'com.ea.gp.apexlegendsmobilefps', 'category': 'Shooter', 'size': '3.5 GB'},
      ];
      _isScanning = false;
    });
  }

  Future<void> _optimizeMemory() async {
    final platform = ref.read(platformServiceProvider);
    final result = await platform.optimizeMemory();
    
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Terminated ${result['killed'] ?? 0} background processes'),
          backgroundColor: const Color(0xFF1E1E1E),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
    }
  }

  List<Map<String, dynamic>> get _filteredGames {
    if (_selectedCategory == 'All') return _games;
    return _games.where((g) => g['category'] == _selectedCategory).toList();
  }

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      physics: const BouncingScrollPhysics(),
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: _buildOptimizeCard(),
          ),
        ),
        SliverToBoxAdapter(
          child: _buildCategoryFilter(),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'INSTALLED GAMES',
                  style: Theme.of(context).textTheme.labelLarge?.copyWith(
                    color: const Color(0xFF808080),
                    letterSpacing: 1.5,
                  ),
                ),
                Text(
                  '${_filteredGames.length} found',
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color(0xFF606060),
                    fontFamily: 'JetBrainsMono',
                  ),
                ),
              ],
            ),
          ),
        ),
        if (_isScanning)
          const SliverFillRemaining(
            child: Center(child: CircularProgressIndicator()),
          )
        else
          SliverPadding(
            padding: const EdgeInsets.all(16),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final game = _filteredGames[index];
                  return _GameCard(
                    name: game['name'] as String,
                    package: game['package'] as String,
                    category: game['category'] as String,
                    size: game['size'] as String,
                    onLaunch: () {},
                    onOptimize: _optimizeMemory,
                  );
                },
                childCount: _filteredGames.length,
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildOptimizeCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF121212),
            Color(0xFF0A0A0A),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.cleaning_services, color: Color(0xFF00E5FF), size: 24),
              SizedBox(width: 12),
              Text(
                'RESOURCE OPTIMIZER',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFFFFFFFF),
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          const Text(
            'Free up system resources by terminating non-essential background processes. This uses only public Android APIs and will not interfere with system services.',
            style: TextStyle(
              fontSize: 12,
              color: Color(0xFF808080),
              height: 1.5,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _optimizeMemory,
                  icon: const Icon(Icons.memory, size: 18),
                  label: const Text('Optimize Now'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF00E5FF),
                    foregroundColor: const Color(0xFF000000),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryFilter() {
    return Container(
      height: 44,
      margin: const EdgeInsets.symmetric(horizontal: 16),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: _categories.length,
        itemBuilder: (context, index) {
          final cat = _categories[index];
          final isSelected = cat == _selectedCategory;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: FilterChip(
              label: Text(
                cat,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                  color: isSelected ? const Color(0xFF000000) : const Color(0xFFCCCCCC),
                ),
              ),
              selected: isSelected,
              onSelected: (selected) {
                setState(() => _selectedCategory = cat);
              },
              backgroundColor: const Color(0xFF1A1A1A),
              selectedColor: const Color(0xFF00E5FF),
              checkmarkColor: const Color(0xFF000000),
              side: BorderSide(
                color: isSelected ? const Color(0xFF00E5FF) : const Color(0xFF2A2A2A),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 4),
            ),
          );
        },
      ),
    );
  }
}

class _GameCard extends StatelessWidget {
  final String name;
  final String package;
  final String category;
  final String size;
  final VoidCallback onLaunch;
  final VoidCallback onOptimize;

  const _GameCard({
    required this.name,
    required this.package,
    required this.category,
    required this.size,
    required this.onLaunch,
    required this.onOptimize,
  });

  Color get _categoryColor {
    switch (category) {
      case 'Shooter': return const Color(0xFFFF1744);
      case 'MOBA': return const Color(0xFF00E5FF);
      case 'RPG': return const Color(0xFF76FF03);
      case 'Racing': return const Color(0xFFFFAB00);
      case 'Sports': return const Color(0xFF9C27B0);
      case 'Strategy': return const Color(0xFFFF9800);
      default: return const Color(0xFF808080);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Row(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: _categoryColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              Icons.games,
              color: _categoryColor,
              size: 28,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFFFFFFFF),
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Text(
                  package,
                  style: const TextStyle(
                    fontSize: 11,
                    color: Color(0xFF606060),
                    fontFamily: 'JetBrainsMono',
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: _categoryColor.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        category,
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: _categoryColor,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      size,
                      style: const TextStyle(
                        fontSize: 11,
                        color: Color(0xFF808080),
                        fontFamily: 'JetBrainsMono',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
