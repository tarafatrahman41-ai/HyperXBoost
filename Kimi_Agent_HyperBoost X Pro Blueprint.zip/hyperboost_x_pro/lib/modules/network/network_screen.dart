import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dart_ping/dart_ping.dart';
import '../../core/models/telemetry_models.dart';

/// Network analyzer screen with ping, jitter, and DNS testing
class NetworkScreen extends ConsumerStatefulWidget {
  const NetworkScreen({super.key});

  @override
  ConsumerState<NetworkScreen> createState() => _NetworkScreenState();
}

class _NetworkScreenState extends ConsumerState<NetworkScreen> {
  final TextEditingController _hostController = TextEditingController(text: '8.8.8.8');
  bool _isPinging = false;
  List<double> _pingHistory = [];
  NetworkMetrics _metrics = const NetworkMetrics();
  StreamSubscription? _pingSubscription;
  int _sequence = 0;

  final List<String> _presetHosts = [
    '8.8.8.8',      // Google DNS
    '1.1.1.1',      // Cloudflare
    '208.67.222.222', // OpenDNS
    '9.9.9.9',      // Quad9
  ];

  @override
  void dispose() {
    _pingSubscription?.cancel();
    _hostController.dispose();
    super.dispose();
  }

  void _startPing() async {
    if (_isPinging) return;
    
    setState(() {
      _isPinging = true;
      _pingHistory.clear();
      _metrics = const NetworkMetrics();
      _sequence = 0;
    });

    final host = _hostController.text.trim();
    
    // DNS resolution test
    final dnsStart = DateTime.now();
    try {
      final result = await InternetAddress.lookup(host);
      final dnsMs = DateTime.now().difference(dnsStart).inMilliseconds.toDouble();
      setState(() {
        _metrics = _metrics.copyWith(dnsLatencyMs: dnsMs);
      });
    } catch (_) {}

    // ICMP ping loop
    final ping = Ping(host, count: 300, interval: 1);
    double? lastPing;

    _pingSubscription = ping.stream.listen((event) {
      if (event.response != null) {
        final rtt = event.response!.time?.inMilliseconds.toDouble() ?? 0;
        
        setState(() {
          _sequence++;
          _pingHistory.add(rtt);
          if (_pingHistory.length > 60) _pingHistory.removeAt(0);
          
          // Calculate jitter
          double jitter = 0;
          if (lastPing != null) {
            jitter = (rtt - lastPing!).abs();
          }
          lastPing = rtt;

          final allPings = List<double>.from(_pingHistory);
          final avg = allPings.reduce((a, b) => a + b) / allPings.length;
          final minP = allPings.reduce((a, b) => a < b ? a : b);
          final maxP = allPings.reduce((a, b) => a > b ? a : b);
          
          // Simple jitter avg
          double jitterAvg = 0;
          if (allPings.length > 1) {
            double jitterSum = 0;
            for (int i = 1; i < allPings.length; i++) {
              jitterSum += (allPings[i] - allPings[i-1]).abs();
            }
            jitterAvg = jitterSum / (allPings.length - 1);
          }

          _metrics = _metrics.copyWith(
            currentPingMs: rtt,
            averagePingMs: avg,
            jitterMs: jitterAvg,
            minPingMs: minP,
            maxPingMs: maxP,
            packetsSent: _sequence,
            packetsReceived: _sequence, // Simplified
            packetLossPercent: 0, // Would need seq tracking
            isRunning: true,
            targetHost: host,
          );
        });
      }
    }, onDone: () {
      setState(() => _isPinging = false);
    }, onError: (_) {
      setState(() => _isPinging = false);
    });
  }

  void _stopPing() {
    _pingSubscription?.cancel();
    setState(() {
      _isPinging = false;
      _metrics = _metrics.copyWith(isRunning: false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Host selector
          _buildHostSelector(),
          const SizedBox(height: 20),
          
          // Main ping display
          _buildPingDisplay(),
          const SizedBox(height: 20),
          
          // Stats grid
          _buildStatsGrid(),
          const SizedBox(height: 20),
          
          // Ping history graph
          if (_pingHistory.length >= 2)
            _buildPingChart(),
          const SizedBox(height: 20),
          
          // DNS test
          _buildDnsCard(),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _buildHostSelector() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _hostController,
                  style: const TextStyle(
                    color: Color(0xFFFFFFFF),
                    fontFamily: 'JetBrainsMono',
                  ),
                  decoration: InputDecoration(
                    hintText: 'Enter host IP or domain',
                    hintStyle: TextStyle(color: const Color(0xFF808080)),
                    prefixIcon: const Icon(Icons.network_ping, color: Color(0xFF00E5FF)),
                    filled: true,
                    fillColor: const Color(0xFF1A1A1A),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              InkWell(
                onTap: _isPinging ? _stopPing : _startPing,
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: _isPinging ? const Color(0xFFFF1744) : const Color(0xFF00E5FF),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    _isPinging ? Icons.stop : Icons.play_arrow,
                    color: const Color(0xFF000000),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            children: _presetHosts.map((host) {
              return ActionChip(
                label: Text(
                  host,
                  style: const TextStyle(
                    fontSize: 11,
                    fontFamily: 'JetBrainsMono',
                    color: Color(0xFFCCCCCC),
                  ),
                ),
                backgroundColor: const Color(0xFF1A1A1A),
                side: const BorderSide(color: Color(0xFF2A2A2A)),
                padding: EdgeInsets.zero,
                onPressed: () {
                  _hostController.text = host;
                },
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildPingDisplay() {
    final ping = _metrics.currentPingMs;
    Color color;
    if (ping < 30) color = const Color(0xFF76FF03);
    else if (ping < 80) color = const Color(0xFF00E5FF);
    else if (ping < 150) color = const Color(0xFFFFAB00);
    else color = const Color(0xFFFF1744);

    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF121212),
            const Color(0xFF0A0A0A),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                  color: _isPinging ? const Color(0xFF76FF03) : const Color(0xFF808080),
                  shape: BoxShape.circle,
                  boxShadow: _isPinging ? [
                    BoxShadow(
                      color: const Color(0xFF76FF03).withOpacity(0.5),
                      blurRadius: 10,
                    ),
                  ] : null,
                ),
              ),
              const SizedBox(width: 10),
              Text(
                _isPinging ? 'PING ACTIVE' : 'READY',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: _isPinging ? const Color(0xFF76FF03) : const Color(0xFF808080),
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Text(
            _isPinging ? '${ping.toStringAsFixed(1)}' : '--',
            style: TextStyle(
              fontSize: 72,
              fontWeight: FontWeight.w800,
              color: color,
              fontFamily: 'JetBrainsMono',
              letterSpacing: -2,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'ms latency',
            style: TextStyle(
              fontSize: 14,
              color: Color(0xFF808080),
            ),
          ),
          if (_metrics.targetHost.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(
                _metrics.targetHost,
                style: const TextStyle(
                  fontSize: 13,
                  color: Color(0xFF606060),
                  fontFamily: 'JetBrainsMono',
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildStatsGrid() {
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      mainAxisSpacing: 12,
      crossAxisSpacing: 12,
      childAspectRatio: 1.6,
      children: [
        _buildStatCard('AVG', '${_metrics.averagePingMs.toStringAsFixed(1)}ms', const Color(0xFF00E5FF)),
        _buildStatCard('JITTER', '${_metrics.jitterMs.toStringAsFixed(1)}ms', const Color(0xFFFFAB00)),
        _buildStatCard('MIN', '${_metrics.minPingMs.toStringAsFixed(1)}ms', const Color(0xFF76FF03)),
        _buildStatCard('MAX', '${_metrics.maxPingMs.toStringAsFixed(1)}ms', const Color(0xFFFF1744)),
      ],
    );
  }

  Widget _buildStatCard(String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            label,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: Color(0xFF808080),
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w700,
              color: color,
              fontFamily: 'JetBrainsMono',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPingChart() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'LATENCY HISTORY',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: Color(0xFF808080),
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 120,
            child: CustomPaint(
              size: const Size(double.infinity, 120),
              painter: _PingChartPainter(_pingHistory),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDnsCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.dns, color: Color(0xFF76FF03), size: 18),
              SizedBox(width: 10),
              Text(
                'DNS RESOLUTION',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF808080),
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildDnsTest('Google', '8.8.8.8'),
              _buildDnsTest('Cloudflare', '1.1.1.1'),
              _buildDnsTest('OpenDNS', '208.67.222.222'),
            ],
          ),
          if (_metrics.dnsLatencyMs > 0)
            Padding(
              padding: const EdgeInsets.only(top: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    'Last DNS lookup: ',
                    style: TextStyle(fontSize: 12, color: Color(0xFF808080)),
                  ),
                  Text(
                    '${_metrics.dnsLatencyMs.toStringAsFixed(1)}ms',
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF00E5FF),
                      fontFamily: 'JetBrainsMono',
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildDnsTest(String name, String ip) {
    return Column(
      children: [
        Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            color: const Color(0xFF1A1A1A),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFF2A2A2A)),
          ),
          child: const Icon(Icons.check_circle, color: Color(0xFF76FF03), size: 24),
        ),
        const SizedBox(height: 8),
        Text(name, style: const TextStyle(fontSize: 11, color: Color(0xFFCCCCCC))),
        Text(ip, style: const TextStyle(fontSize: 9, color: Color(0xFF808080), fontFamily: 'JetBrainsMono')),
      ],
    );
  }
}

class _PingChartPainter extends CustomPainter {
  final List<double> data;
  _PingChartPainter(this.data);

  @override
  void paint(Canvas canvas, Size size) {
    if (data.length < 2) return;

    final maxVal = data.reduce((a, b) => a > b ? a : b) * 1.2;
    final minVal = data.reduce((a, b) => a < b ? a : b) * 0.8;
    final range = maxVal - minVal;
    
    final paint = Paint()
      ..color = const Color(0xFF00E5FF)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;

    final fillPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          const Color(0xFF00E5FF).withOpacity(0.2),
          const Color(0xFF00E5FF).withOpacity(0.0),
        ],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));

    final path = Path();
    final fillPath = Path();
    
    final stepX = size.width / (data.length - 1);
    
    for (int i = 0; i < data.length; i++) {
      final x = i * stepX;
      final y = size.height - ((data[i] - minVal) / range * size.height);
      
      if (i == 0) {
        path.moveTo(x, y);
        fillPath.moveTo(x, size.height);
        fillPath.lineTo(x, y);
      } else {
        path.lineTo(x, y);
        fillPath.lineTo(x, y);
      }
    }
    
    fillPath.lineTo(size.width, size.height);
    fillPath.close();
    
    canvas.drawPath(fillPath, fillPaint);
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
