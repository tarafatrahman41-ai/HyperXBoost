import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../../core/models/telemetry_models.dart';

/// Dashboard overview widget builders
class DashboardOverview {
  
  static Widget buildFpsCard(BuildContext context, FrameMetrics metrics) {
    final fps = metrics.currentFps;
    final isStutter = metrics.frameDropped;
    final targetFps = metrics.targetRefreshRate;
    
    Color fpsColor;
    if (fps >= targetFps * 0.95) {
      fpsColor = const Color(0xFF76FF03);
    } else if (fps >= targetFps * 0.8) {
      fpsColor = const Color(0xFFFFAB00);
    } else {
      fpsColor = const Color(0xFFFF1744);
    }

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isStutter ? const Color(0xFFFF1744).withOpacity(0.5) : const Color(0xFF2A2A2A),
        ),
        boxShadow: isStutter ? [
          BoxShadow(
            color: const Color(0xFFFF1744).withOpacity(0.1),
            blurRadius: 16,
          ),
        ] : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(
                    Icons.speed,
                    color: fpsColor,
                    size: 20,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'FPS',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: const Color(0xFF808080),
                      letterSpacing: 1.5,
                    ),
                  ),
                ],
              ),
              if (isStutter)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFF1744).withOpacity(0.15),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: const Text(
                    'STUTTER',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFFFF1744),
                      letterSpacing: 1,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                fps.toStringAsFixed(1),
                style: TextStyle(
                  fontSize: 56,
                  fontWeight: FontWeight.w700,
                  color: fpsColor,
                  fontFamily: 'JetBrainsMono',
                  letterSpacing: -2,
                  height: 1,
                ),
              ),
              const SizedBox(width: 8),
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Text(
                  '/ ${targetFps}Hz',
                  style: const TextStyle(
                    fontSize: 16,
                    color: Color(0xFF808080),
                    fontFamily: 'JetBrainsMono',
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _buildFpsStat('AVG', metrics.averageFps.toStringAsFixed(1), const Color(0xFF00E5FF)),
              const SizedBox(width: 24),
              _buildFpsStat('1% LOW', metrics.onePercentLow.toStringAsFixed(1), const Color(0xFF76FF03)),
              const SizedBox(width: 24),
              _buildFpsStat('0.1% LOW', metrics.pointOnePercentLow.toStringAsFixed(1), const Color(0xFFFFAB00)),
            ],
          ),
        ],
      ),
    );
  }

  static Widget _buildFpsStat(String label, String value, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 10,
            color: Color(0xFF808080),
            letterSpacing: 1,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: color,
            fontFamily: 'JetBrainsMono',
          ),
        ),
      ],
    );
  }

  static Widget buildCpuCard(BuildContext context, CpuTelemetry cpu) {
    final load = cpu.loadPercent;
    final color = load > 80 ? const Color(0xFFFF1744) 
        : load > 50 ? const Color(0xFFFFAB00) 
        : const Color(0xFF00E5FF);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.memory, color: Color(0xFF00E5FF), size: 18),
              const SizedBox(width: 8),
              const Text(
                'CPU',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF808080),
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            '${load.toStringAsFixed(1)}%',
            style: TextStyle(
              fontSize: 32,
              fontWeight: FontWeight.w700,
              color: color,
              fontFamily: 'JetBrainsMono',
            ),
          ),
          const SizedBox(height: 8),
          if (cpu.coreFrequenciesMhz.isNotEmpty)
            Text(
              '${cpu.coreCount} cores | ${_getAvgFreq(cpu.coreFrequenciesMhz)} MHz avg',
              style: const TextStyle(
                fontSize: 11,
                color: Color(0xFF808080),
                fontFamily: 'JetBrainsMono',
              ),
            ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: load / 100.0,
              backgroundColor: const Color(0xFF1E1E1E),
              valueColor: AlwaysStoppedAnimation<Color>(color),
              minHeight: 6,
            ),
          ),
        ],
      ),
    );
  }

  static Widget buildGpuCard(BuildContext context, GpuTelemetry gpu) {
    if (!gpu.available || gpu.usagePercent < 0) {
      return _buildUnavailableCard('GPU', Icons.graphic_eq);
    }

    final usage = gpu.usagePercent;
    final color = usage > 90 ? const Color(0xFFFF1744)
        : usage > 70 ? const Color(0xFFFFAB00)
        : const Color(0xFF76FF03);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.graphic_eq, color: Color(0xFF76FF03), size: 18),
              const SizedBox(width: 8),
              const Text(
                'GPU',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF808080),
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            '$usage%',
            style: TextStyle(
              fontSize: 32,
              fontWeight: FontWeight.w700,
              color: color,
              fontFamily: 'JetBrainsMono',
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '${gpu.frequencyMhz} MHz',
            style: const TextStyle(
              fontSize: 11,
              color: Color(0xFF808080),
              fontFamily: 'JetBrainsMono',
            ),
          ),
          const SizedBox(height: 4),
          Text(
            gpu.vendorName,
            style: const TextStyle(
              fontSize: 10,
              color: Color(0xFF606060),
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: usage / 100.0,
              backgroundColor: const Color(0xFF1E1E1E),
              valueColor: AlwaysStoppedAnimation<Color>(color),
              minHeight: 6,
            ),
          ),
        ],
      ),
    );
  }

  static Widget buildMemoryCard(BuildContext context, MemoryTelemetry memory) {
    final usedPercent = memory.usedPercent;
    final color = usedPercent > 90 ? const Color(0xFFFF1744)
        : usedPercent > 75 ? const Color(0xFFFFAB00)
        : const Color(0xFF00E5FF);

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.storage, color: Color(0xFFFFAB00), size: 20),
              const SizedBox(width: 8),
              const Text(
                'MEMORY',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF808080),
                  letterSpacing: 1.5,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  '${usedPercent.toStringAsFixed(1)}%',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: color,
                    fontFamily: 'JetBrainsMono',
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildMemStat('Total', '${memory.totalMb} MB'),
              _buildMemStat('Used', '${memory.usedMb} MB'),
              _buildMemStat('Available', '${memory.availableMb} MB'),
            ],
          ),
          const SizedBox(height: 16),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: usedPercent / 100.0,
              backgroundColor: const Color(0xFF1E1E1E),
              valueColor: AlwaysStoppedAnimation<Color>(color),
              minHeight: 8,
            ),
          ),
        ],
      ),
    );
  }

  static Widget _buildMemStat(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 10,
            color: Color(0xFF808080),
            letterSpacing: 1,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: Color(0xFFFFFFFF),
            fontFamily: 'JetBrainsMono',
          ),
        ),
      ],
    );
  }

  static Widget buildThermalCard(
    BuildContext context, 
    List<ThermalZone> zones, 
    bool throttling,
  ) {
    final hottest = zones.isNotEmpty 
        ? zones.reduce((a, b) => a.temperatureC > b.temperatureC ? a : b)
        : null;
    final temp = hottest?.temperatureC ?? 0;
    
    final color = throttling ? const Color(0xFFFF1744)
        : temp > 70 ? const Color(0xFFFFAB00)
        : const Color(0xFF00E5FF);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: throttling ? const Color(0xFFFF1744).withOpacity(0.5) : const Color(0xFF2A2A2A),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.thermostat, color: color, size: 18),
              const SizedBox(width: 8),
              const Text(
                'THERMAL',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF808080),
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            '${temp.toStringAsFixed(1)}°C',
            style: TextStyle(
              fontSize: 32,
              fontWeight: FontWeight.w700,
              color: color,
              fontFamily: 'JetBrainsMono',
            ),
          ),
          const SizedBox(height: 8),
          if (hottest != null)
            Text(
              hottest.name,
              style: const TextStyle(
                fontSize: 11,
                color: Color(0xFF808080),
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          if (throttling)
            Container(
              margin: const EdgeInsets.only(top: 8),
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: const Color(0xFFFF1744).withOpacity(0.15),
                borderRadius: BorderRadius.circular(6),
              ),
              child: const Text(
                'THROTTLING DETECTED',
                style: TextStyle(
                  fontSize: 9,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFFFF1744),
                  letterSpacing: 1,
                ),
              ),
            ),
        ],
      ),
    );
  }

  static Widget buildBatteryCard(
    BuildContext context,
    int level,
    double tempC,
  ) {
    final batteryColor = level < 20 ? const Color(0xFFFF1744)
        : level < 50 ? const Color(0xFFFFAB00)
        : const Color(0xFF76FF03);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.battery_full, color: Color(0xFF76FF03), size: 18),
              const SizedBox(width: 8),
              const Text(
                'BATTERY',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF808080),
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            '$level%',
            style: TextStyle(
              fontSize: 32,
              fontWeight: FontWeight.w700,
              color: batteryColor,
              fontFamily: 'JetBrainsMono',
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '${tempC.toStringAsFixed(1)}°C',
            style: const TextStyle(
              fontSize: 13,
              color: Color(0xFF808080),
              fontFamily: 'JetBrainsMono',
            ),
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: level / 100.0,
              backgroundColor: const Color(0xFF1E1E1E),
              valueColor: AlwaysStoppedAnimation<Color>(batteryColor),
              minHeight: 6,
            ),
          ),
        ],
      ),
    );
  }

  static Widget buildFpsChart(BuildContext context, List<double> fpsHistory) {
    if (fpsHistory.length < 2) return const SizedBox.shrink();

    final spots = fpsHistory.asMap().entries.map((e) {
      return FlSpot(e.key.toDouble(), e.value);
    }).toList();

    final minFps = fpsHistory.reduce((a, b) => a < b ? a : b);
    final maxFps = fpsHistory.reduce((a, b) => a > b ? a : b);

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.show_chart, color: Color(0xFF00E5FF), size: 18),
              SizedBox(width: 8),
              Text(
                'FPS HISTORY',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF808080),
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 150,
            child: LineChart(
              LineChartData(
                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: false,
                  horizontalInterval: 30,
                  getDrawingHorizontalLine: (value) {
                    return const FlLine(
                      color: Color(0xFF1E1E1E),
                      strokeWidth: 1,
                    );
                  },
                ),
                titlesData: FlTitlesData(
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 40,
                      getTitlesWidget: (value, meta) {
                        return Text(
                          value.toInt().toString(),
                          style: const TextStyle(
                            fontSize: 10,
                            color: Color(0xFF808080),
                            fontFamily: 'JetBrainsMono',
                          ),
                        );
                      },
                    ),
                  ),
                  bottomTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                ),
                borderData: FlBorderData(show: false),
                minY: (minFps * 0.8).clamp(0, double.infinity),
                maxY: maxFps * 1.1,
                lineBarsData: [
                  LineChartBarData(
                    spots: spots,
                    isCurved: true,
                    color: const Color(0xFF00E5FF),
                    barWidth: 2,
                    isStrokeCapRound: true,
                    dotData: const FlDotData(show: false),
                    belowBarData: BarAreaData(
                      show: true,
                      color: const Color(0xFF00E5FF).withOpacity(0.1),
                    ),
                  ),
                ],
                lineTouchData: const LineTouchData(enabled: false),
              ),
            ),
          ),
        ],
      ),
    );
  }

  static Widget _buildUnavailableCard(String label, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: const Color(0xFF808080), size: 18),
              const SizedBox(width: 8),
              Text(
                label,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF808080),
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Text(
            'N/A',
            style: TextStyle(
              fontSize: 32,
              fontWeight: FontWeight.w700,
              color: Color(0xFF808080),
              fontFamily: 'JetBrainsMono',
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Unavailable on this device',
            style: TextStyle(
              fontSize: 11,
              color: Color(0xFF606060),
            ),
          ),
        ],
      ),
    );
  }

  static int _getAvgFreq(List<int> freqs) {
    if (freqs.isEmpty) return 0;
    return freqs.reduce((a, b) => a + b) ~/ freqs.length;
  }
}
