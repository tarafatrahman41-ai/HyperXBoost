import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/providers/app_providers.dart';
import '../fps_monitor/fps_monitor_screen.dart';
import '../hardware/hardware_screen.dart';
import '../network/network_screen.dart';
import '../thermal/thermal_screen.dart';
import '../games/games_screen.dart';
import '../settings/settings_screen.dart';
import 'widgets/dashboard_overview.dart';

/// Main dashboard screen with bottom navigation
class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedIndex = ref.watch(selectedTabProvider);
    
    final screens = [
      const OverviewTab(),
      const FpsMonitorScreen(),
      const HardwareScreen(),
      const NetworkScreen(),
      const GamesScreen(),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFF000000),
      appBar: AppBar(
        backgroundColor: const Color(0xFF000000),
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 8,
              height: 8,
              decoration: BoxDecoration(
                color: ref.watch(telemetryActiveProvider) 
                    ? const Color(0xFF76FF03) 
                    : const Color(0xFFFF1744),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: ref.watch(telemetryActiveProvider) 
                        ? const Color(0xFF76FF03).withOpacity(0.5)
                        : const Color(0xFFFF1744).withOpacity(0.5),
                    blurRadius: 8,
                    spreadRadius: 2,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Text(
              'HyperBoost X Pro',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w700,
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            ),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: screens[selectedIndex],
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF121212),
          border: Border(
            top: BorderSide(
              color: const Color(0xFF2A2A2A),
              width: 1,
            ),
          ),
        ),
        child: SafeArea(
          child: BottomNavigationBar(
            currentIndex: selectedIndex,
            onTap: (index) => ref.read(selectedTabProvider.notifier).state = index,
            backgroundColor: Colors.transparent,
            elevation: 0,
            type: BottomNavigationBarType.fixed,
            selectedItemColor: const Color(0xFF00E5FF),
            unselectedItemColor: const Color(0xFF808080),
            selectedLabelStyle: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              fontFamily: 'Inter',
            ),
            unselectedLabelStyle: const TextStyle(
              fontSize: 11,
              fontFamily: 'Inter',
            ),
            items: const [
              BottomNavigationBarItem(
                icon: Icon(Icons.dashboard_outlined),
                activeIcon: Icon(Icons.dashboard),
                label: 'Dashboard',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.speed_outlined),
                activeIcon: Icon(Icons.speed),
                label: 'FPS',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.memory_outlined),
                activeIcon: Icon(Icons.memory),
                label: 'Hardware',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.network_ping_outlined),
                activeIcon: Icon(Icons.network_ping),
                label: 'Network',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.games_outlined),
                activeIcon: Icon(Icons.games),
                label: 'Games',
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Overview tab content
class OverviewTab extends ConsumerWidget {
  const OverviewTab({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final telemetry = ref.watch(currentTelemetryProvider);
    final frameMetrics = ref.watch(currentFrameMetricsProvider);
    final isActive = ref.watch(telemetryActiveProvider);

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Status bar
          _buildStatusBar(context, isActive),
          const SizedBox(height: 20),
          
          // Quick actions
          _buildQuickActions(context, ref),
          const SizedBox(height: 24),
          
          // FPS Card
          DashboardOverview.buildFpsCard(context, frameMetrics),
          const SizedBox(height: 16),
          
          // CPU & GPU Row
          Row(
            children: [
              Expanded(
                child: DashboardOverview.buildCpuCard(context, telemetry.cpu),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: DashboardOverview.buildGpuCard(context, telemetry.gpu),
              ),
            ],
          ),
          const SizedBox(height: 16),
          
          // Memory Card
          DashboardOverview.buildMemoryCard(context, telemetry.memory),
          const SizedBox(height: 16),
          
          // Thermal & Battery Row
          Row(
            children: [
              Expanded(
                child: DashboardOverview.buildThermalCard(
                  context, 
                  telemetry.thermalZones, 
                  telemetry.thermalThrottling,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: DashboardOverview.buildBatteryCard(
                  context,
                  telemetry.batteryLevelPercent,
                  telemetry.batteryTempC,
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          
          // FPS Mini Chart
          if (ref.watch(fpsHistoryProvider).isNotEmpty)
            DashboardOverview.buildFpsChart(context, ref.watch(fpsHistoryProvider)),
          
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _buildStatusBar(BuildContext context, bool isActive) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Row(
        children: [
          Icon(
            isActive ? Icons.fiber_manual_record : Icons.radio_button_unchecked,
            color: isActive ? const Color(0xFF76FF03) : const Color(0xFF808080),
            size: 14,
          ),
          const SizedBox(width: 8),
          Text(
            isActive ? 'TELEMETRY ACTIVE' : 'TELEMETRY IDLE',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: isActive ? const Color(0xFF76FF03) : const Color(0xFF808080),
              letterSpacing: 1.5,
            ),
          ),
          const Spacer(),
          Text(
            'HyperBoost X Pro v1.0.0',
            style: TextStyle(
              fontSize: 11,
              color: const Color(0xFF808080),
              fontFamily: 'JetBrainsMono',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActions(BuildContext context, WidgetRef ref) {
    return Row(
      children: [
        Expanded(
          child: _ActionButton(
            icon: ref.watch(telemetryActiveProvider) 
                ? Icons.stop_circle 
                : Icons.play_circle_fill,
            label: ref.watch(telemetryActiveProvider) ? 'Stop' : 'Start',
            color: ref.watch(telemetryActiveProvider) 
                ? const Color(0xFFFF1744) 
                : const Color(0xFF00E5FF),
            onTap: () async {
              final manager = ref.read(telemetryManagerProvider.notifier);
              if (ref.read(telemetryActiveProvider)) {
                await manager.stop();
                ref.read(telemetryActiveProvider.notifier).state = false;
              } else {
                await manager.start(intervalMs: 500);
                manager.listenToStreams(ref);
                ref.read(telemetryActiveProvider.notifier).state = true;
              }
            },
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _ActionButton(
            icon: Icons.layers,
            label: 'Overlay',
            color: const Color(0xFF76FF03),
            onTap: () async {
              final platform = ref.read(platformServiceProvider);
              if (await platform.canDrawOverlays()) {
                await platform.showOverlay();
              } else {
                await platform.requestOverlayPermission();
              }
            },
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _ActionButton(
            icon: Icons.cleaning_services,
            label: 'Optimize',
            color: const Color(0xFFFFAB00),
            onTap: () async {
              final platform = ref.read(platformServiceProvider);
              final result = await platform.optimizeMemory();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Killed ${result['killed'] ?? 0} background processes'),
                  backgroundColor: const Color(0xFF1E1E1E),
                  behavior: SnackBarBehavior.floating,
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _ActionButton({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: const Color(0xFF121212),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 28),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontSize: 13,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
