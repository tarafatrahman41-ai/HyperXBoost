import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../core/providers/app_providers.dart';

/// Detailed FPS monitoring screen with frame-time analysis
class FpsMonitorScreen extends ConsumerWidget {
  const FpsMonitorScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final metrics = ref.watch(currentFrameMetricsProvider);
    final fpsHistory = ref.watch(fpsHistoryProvider);
    
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Main FPS display
          _buildMainFpsDisplay(context, metrics),
          const SizedBox(height: 20),
          
          // Frame time distribution
          _buildFrameTimeStats(context, metrics),
          const SizedBox(height: 20),
          
          // FPS Chart
          if (fpsHistory.length >= 2)
            _buildDetailedFpsChart(context, fpsHistory, metrics.targetRefreshRate),
          const SizedBox(height: 20),
          
          // Frame quality indicators
          _buildFrameQualityCard(context, metrics),
          const SizedBox(height: 20),
          
          // Stutter log
          _buildStutterInfo(context, metrics),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _buildMainFpsDisplay(BuildContext context, FrameMetrics metrics) {
    final fps = metrics.currentFps;
    final target = metrics.targetRefreshRate;
    final targetFrameTime = 1000.0 / target;
    
    Color fpsColor;
    if (fps >= target * 0.98) {
      fpsColor = const Color(0xFF76FF03);
    } else if (fps >= target * 0.9) {
      fpsColor = const Color(0xFF00E5FF);
    } else if (fps >= target * 0.75) {
      fpsColor = const Color(0xFFFFAB00);
    } else {
      fpsColor = const Color(0xFFFF1744);
    }

    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF121212),
            const Color(0xFF0A0A0A),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: fpsColor.withOpacity(0.3),
          width: 1.5,
        ),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  color: fpsColor,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: fpsColor.withOpacity(0.4),
                      blurRadius: 12,
                      spreadRadius: 2,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Text(
                'REAL-TIME FPS',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: const Color(0xFF808080),
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Text(
            fps.toStringAsFixed(1),
            style: TextStyle(
              fontSize: 96,
              fontWeight: FontWeight.w800,
              color: fpsColor,
              fontFamily: 'JetBrainsMono',
              letterSpacing: -4,
              height: 1,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '/ ${target}Hz Target | ${targetFrameTime.toStringAsFixed(2)}ms/frame',
            style: const TextStyle(
              fontSize: 14,
              color: Color(0xFF808080),
              fontFamily: 'JetBrainsMono',
            ),
          ),
          if (metrics.frameDropped)
            Container(
              margin: const EdgeInsets.only(top: 16),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: const Color(0xFFFF1744).withOpacity(0.15),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: const Color(0xFFFF1744).withOpacity(0.3),
                ),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.warning_amber, color: Color(0xFFFF1744), size: 16),
                  SizedBox(width: 8),
                  Text(
                    'FRAME DROP DETECTED',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFFFF1744),
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildFrameTimeStats(BuildContext context, FrameMetrics metrics) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'FRAME STATISTICS',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: Color(0xFF808080),
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(child: _buildStatBox('AVERAGE', metrics.averageFps.toStringAsFixed(1), 'FPS', const Color(0xFF00E5FF))),
              const SizedBox(width: 12),
              Expanded(child: _buildStatBox('1% LOW', metrics.onePercentLow.toStringAsFixed(1), 'FPS', const Color(0xFF76FF03))),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: _buildStatBox('0.1% LOW', metrics.pointOnePercentLow.toStringAsFixed(1), 'FPS', const Color(0xFFFFAB00))),
              const SizedBox(width: 12),
              Expanded(child: _buildStatBox('FRAME TIME', '${metrics.lastFrameTimeMs.toStringAsFixed(2)}', 'ms', const Color(0xFFFF9800))),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: _buildStatBox('VARIANCE', metrics.frameVariance.toStringAsFixed(3), 'ms²', const Color(0xFFE040FB))),
              const SizedBox(width: 12),
              Expanded(child: _buildStatBox('STUTTERS', '${metrics.stutterCount}', 'events', const Color(0xFFFF1744))),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatBox(String label, String value, String unit, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w600,
              color: Color(0xFF808080),
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            crossAxisAlignment: BaselineAlignment.alphabetic,
            textBaseline: TextBaseline.alphabetic,
            children: [
              Text(
                value,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w700,
                  color: color,
                  fontFamily: 'JetBrainsMono',
                ),
              ),
              const SizedBox(width: 4),
              Text(
                unit,
                style: const TextStyle(
                  fontSize: 11,
                  color: Color(0xFF808080),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDetailedFpsChart(BuildContext context, List<double> fpsHistory, int targetFps) {
    final spots = fpsHistory.asMap().entries.map((e) {
      return FlSpot(e.key.toDouble(), e.value);
    }).toList();

    final minFps = fpsHistory.reduce((a, b) => a < b ? a : b) * 0.9;
    final maxFps = fpsHistory.reduce((a, b) => a > b ? a : b) * 1.1;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'FPS HISTORY',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF808080),
                  letterSpacing: 1.5,
                ),
              ),
              Text(
                '120 points',
                style: TextStyle(
                  fontSize: 11,
                  color: Color(0xFF606060),
                  fontFamily: 'JetBrainsMono',
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: 200,
            child: LineChart(
              LineChartData(
                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: true,
                  verticalInterval: 20,
                  horizontalInterval: 30,
                  getDrawingHorizontalLine: (value) {
                    return FlLine(
                      color: value == targetFps.toDouble()
                          ? const Color(0xFF76FF03).withOpacity(0.3)
                          : const Color(0xFF1E1E1E),
                      strokeWidth: value == targetFps.toDouble() ? 1.5 : 0.5,
                      dashArray: value == targetFps.toDouble() ? [6, 4] : null,
                    );
                  },
                  getDrawingVerticalLine: (value) {
                    return const FlLine(
                      color: Color(0xFF1E1E1E),
                      strokeWidth: 0.5,
                    );
                  },
                ),
                titlesData: FlTitlesData(
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 44,
                      getTitlesWidget: (value, meta) {
                        return Text(
                          value.toInt().toString(),
                          style: const TextStyle(
                            fontSize: 10,
                            color: Color(0xFF808080),
                            fontFamily: 'JetBrainsMono',
                          ),
                        );
                      },
                    ),
                  ),
                  bottomTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                ),
                borderData: FlBorderData(show: false),
                minY: minFps.clamp(0, double.infinity),
                maxY: maxFps,
                lineBarsData: [
                  LineChartBarData(
                    spots: spots,
                    isCurved: true,
                    curveSmoothness: 0.3,
                    color: const Color(0xFF00E5FF),
                    barWidth: 2.5,
                    isStrokeCapRound: true,
                    dotData: const FlDotData(show: false),
                    belowBarData: BarAreaData(
                      show: true,
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          const Color(0xFF00E5FF).withOpacity(0.2),
                          const Color(0xFF00E5FF).withOpacity(0.0),
                        ],
                      ),
                    ),
                  ),
                ],
                lineTouchData: LineTouchData(
                  touchTooltipData: LineTouchTooltipData(
                    tooltipRoundedRadius: 8,
                    getTooltipColor: (touchedSpot) => const Color(0xFF1E1E1E),
                    getTooltipItems: (spots) {
                      return spots.map((spot) {
                        return LineTooltipItem(
                          spot.y.toStringAsFixed(1),
                          const TextStyle(
                            color: Color(0xFF00E5FF),
                            fontFamily: 'JetBrainsMono',
                            fontWeight: FontWeight.w700,
                          ),
                        );
                      }).toList();
                    },
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFrameQualityCard(BuildContext context, FrameMetrics metrics) {
    final targetMs = metrics.targetFrameTimeMs;
    final lastMs = metrics.lastFrameTimeMs;
    
    double qualityPercent = 0;
    if (lastMs > 0 && targetMs > 0) {
      qualityPercent = (targetMs / lastMs * 100).clamp(0, 100);
    }

    String quality;
    Color color;
    if (qualityPercent >= 98) {
      quality = 'EXCELLENT';
      color = const Color(0xFF76FF03);
    } else if (qualityPercent >= 90) {
      quality = 'GOOD';
      color = const Color(0xFF00E5FF);
    } else if (qualityPercent >= 75) {
      quality = 'ACCEPTABLE';
      color = const Color(0xFFFFAB00);
    } else {
      quality = 'POOR';
      color = const Color(0xFFFF1744);
    }

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'FRAME QUALITY',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF808080),
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  quality,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w700,
                    color: color,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Target: ${targetMs.toStringAsFixed(2)}ms | Actual: ${lastMs.toStringAsFixed(2)}ms',
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color(0xFF808080),
                    fontFamily: 'JetBrainsMono',
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            width: 60,
            height: 60,
            child: CircularProgressIndicator(
              value: qualityPercent / 100,
              strokeWidth: 6,
              backgroundColor: const Color(0xFF1E1E1E),
              valueColor: AlwaysStoppedAnimation<Color>(color),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStutterInfo(BuildContext context, FrameMetrics metrics) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'STUTTER ANALYSIS',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: Color(0xFF808080),
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildStutterMetric('Total Stutters', '${metrics.stutterCount}', const Color(0xFFFF1744)),
              _buildStutterMetric('Total Frames', '${metrics.totalFrames}', const Color(0xFF00E5FF)),
              _buildStutterMetric('Stutter Rate', 
                metrics.totalFrames > 0 
                    ? '${(metrics.stutterCount / metrics.totalFrames * 100).toStringAsFixed(3)}%' 
                    : '0%', 
                const Color(0xFFFFAB00)),
            ],
          ),
          const SizedBox(height: 16),
          const Text(
            'Stutter Detection Threshold: Frame time exceeds 1.5x target frame time',
            style: TextStyle(
              fontSize: 11,
              color: Color(0xFF606060),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStutterMetric(String label, String value, Color color) {
    return Column(
      children: [
        Text(
          value,
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w700,
            color: color,
            fontFamily: 'JetBrainsMono',
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(
            fontSize: 10,
            color: Color(0xFF808080),
          ),
        ),
      ],
    );
  }
}
