import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/telemetry_models.dart';
import '../services/platform_service.dart';

// Platform service provider
final platformServiceProvider = Provider<PlatformService>((ref) {
  return PlatformService();
});

// Theme mode provider
final themeModeProvider = StateProvider<ThemeMode>((ref) => ThemeMode.dark);

// Telemetry stream provider
final telemetryStreamProvider = StreamProvider<TelemetrySnapshot>((ref) {
  final platform = ref.watch(platformServiceProvider);
  return platform.telemetryStream.map((data) => platform.parseTelemetryData(data));
});

// Frame metrics stream provider
final frameMetricsStreamProvider = StreamProvider<FrameMetrics>((ref) {
  final platform = ref.watch(platformServiceProvider);
  return platform.frameStream.map((data) => platform.parseFrameMetrics(data));
});

// Current telemetry snapshot
final currentTelemetryProvider = StateProvider<TelemetrySnapshot>((ref) {
  return const TelemetrySnapshot();
});

// Current frame metrics
final currentFrameMetricsProvider = StateProvider<FrameMetrics>((ref) {
  return const FrameMetrics();
});

// Telemetry active state
final telemetryActiveProvider = StateProvider<bool>((ref) => false);

// Overlay active state
final overlayActiveProvider = StateProvider<bool>((ref) => false);

// Recording active state
final recordingActiveProvider = StateProvider<bool>((ref) => false);

// App settings provider
final appSettingsProvider = StateProvider<AppSettings>((ref) {
  return const AppSettings();
});

// Selected tab index
final selectedTabProvider = StateProvider<int>((ref) => 0);

// Device info provider
final deviceInfoProvider = FutureProvider<Map<dynamic, dynamic>>((ref) async {
  final platform = ref.watch(platformServiceProvider);
  return platform.getDeviceInfo();
});

// Memory status provider
final memoryStatusProvider = FutureProvider<Map<dynamic, dynamic>>((ref) async {
  final platform = ref.watch(platformServiceProvider);
  return platform.getMemoryStatus();
});

// Telemetry history ring buffer (last 60 seconds at 2Hz = 120 points)
final telemetryHistoryProvider = StateProvider<List<TelemetrySnapshot>>((ref) {
  return [];
});

// FPS history for charts (last 120 points)
final fpsHistoryProvider = StateProvider<List<double>>((ref) {
  return [];
});

// Network metrics provider
final networkMetricsProvider = StateProvider<NetworkMetrics>((ref) {
  return const NetworkMetrics();
});

// Thermal zones sorted by temperature
final sortedThermalZonesProvider = Provider<List<ThermalZone>>((ref) {
  final telemetry = ref.watch(currentTelemetryProvider);
  final zones = List<ThermalZone>.from(telemetry.thermalZones);
  zones.sort((a, b) => b.temperatureC.compareTo(a.temperatureC));
  return zones;
});

// Hottest thermal zone
final hottestZoneProvider = Provider<ThermalZone?>((ref) {
  final zones = ref.watch(sortedThermalZonesProvider);
  return zones.isNotEmpty ? zones.first : null;
});

// Service manager for lifecycle operations
class TelemetryServiceManager extends StateNotifier<bool> {
  final PlatformService _platform;
  StreamSubscription? _telemetrySub;
  StreamSubscription? _frameSub;

  TelemetryServiceManager(this._platform) : super(false);

  Future<void> start({int intervalMs = 500}) async {
    try {
      await _platform.startTelemetry(intervalMs);
      state = true;
    } catch (e) {
      state = false;
      rethrow;
    }
  }

  Future<void> stop() async {
    await _telemetrySub?.cancel();
    await _frameSub?.cancel();
    await _platform.stopTelemetry();
    state = false;
  }

  void listenToStreams(WidgetRef ref) {
    _telemetrySub?.cancel();
    _telemetrySub = _platform.telemetryStream.listen((data) {
      final snapshot = _platform.parseTelemetryData(data);
      ref.read(currentTelemetryProvider.notifier).state = snapshot;
      
      // Update history
      final history = ref.read(telemetryHistoryProvider);
      final newHistory = [...history, snapshot];
      if (newHistory.length > 120) {
        newHistory.removeAt(0);
      }
      ref.read(telemetryHistoryProvider.notifier).state = newHistory;
    });

    _frameSub?.cancel();
    _frameSub = _platform.frameStream.listen((data) {
      final metrics = _platform.parseFrameMetrics(data);
      ref.read(currentFrameMetricsProvider.notifier).state = metrics;
      
      // Update FPS history
      final fpsHistory = ref.read(fpsHistoryProvider);
      final newHistory = [...fpsHistory, metrics.currentFps];
      if (newHistory.length > 120) {
        newHistory.removeAt(0);
      }
      ref.read(fpsHistoryProvider.notifier).state = newHistory;
    });
  }

  @override
  void dispose() {
    _telemetrySub?.cancel();
    _frameSub?.cancel();
    super.dispose();
  }
}

final telemetryManagerProvider = StateNotifierProvider<TelemetryServiceManager, bool>((ref) {
  final platform = ref.watch(platformServiceProvider);
  return TelemetryServiceManager(platform);
});
