import 'dart:async';
import 'package:flutter/services.dart';
import '../models/telemetry_models.dart';

/// Platform channel service for native Android communication
class PlatformService {
  static const MethodChannel _platform = MethodChannel(
    'com.hyperboost.xpro/platform',
  );
  static const EventChannel _telemetryChannel = EventChannel(
    'com.hyperboost.xpro/telemetry/data',
  );
  static const EventChannel _frameChannel = EventChannel(
    'com.hyperboost.xpro/telemetry/frames',
  );

  Stream<Map<dynamic, dynamic>>? _telemetryStream;
  Stream<Map<dynamic, dynamic>>? _frameStream;

  /// Stream of telemetry data from native layer
  Stream<Map<dynamic, dynamic>> get telemetryStream {
    _telemetryStream ??= _telemetryChannel
        .receiveBroadcastStream()
        .cast<Map<dynamic, dynamic>>();
    return _telemetryStream!;
  }

  /// Stream of frame metrics from native layer
  Stream<Map<dynamic, dynamic>> get frameStream {
    _frameStream ??= _frameChannel
        .receiveBroadcastStream()
        .cast<Map<dynamic, dynamic>>();
    return _frameStream!;
  }

  /// Start telemetry service
  Future<bool> startTelemetry(int intervalMs) async {
    try {
      return await _platform.invokeMethod('startTelemetry', {
        'intervalMs': intervalMs,
      }) ?? false;
    } on PlatformException catch (e) {
      throw PlatformException(
        code: e.code,
        message: 'Failed to start telemetry: ${e.message}',
      );
    }
  }

  /// Stop telemetry service
  Future<bool> stopTelemetry() async {
    try {
      return await _platform.invokeMethod('stopTelemetry') ?? false;
    } on PlatformException catch (e) {
      throw PlatformException(
        code: e.code,
        message: 'Failed to stop telemetry: ${e.message}',
      );
    }
  }

  /// Check if telemetry is running
  Future<bool> isTelemetryRunning() async {
    try {
      return await _platform.invokeMethod('isTelemetryRunning') ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Request overlay permission
  Future<bool> requestOverlayPermission() async {
    try {
      return await _platform.invokeMethod('requestOverlayPermission') ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Check overlay permission
  Future<bool> canDrawOverlays() async {
    try {
      return await _platform.invokeMethod('canDrawOverlays') ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Show floating overlay
  Future<bool> showOverlay() async {
    try {
      return await _platform.invokeMethod('showOverlay') ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Hide floating overlay
  Future<bool> hideOverlay() async {
    try {
      return await _platform.invokeMethod('hideOverlay') ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Start screen recording
  Future<bool> startRecording({
    String? outputPath,
    int width = 1920,
    int height = 1080,
    int bitrate = 12000000,
    int fps = 60,
  }) async {
    try {
      return await _platform.invokeMethod('startRecording', {
        'outputPath': outputPath,
        'width': width,
        'height': height,
        'bitrate': bitrate,
        'fps': fps,
      }) ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Stop screen recording
  Future<bool> stopRecording() async {
    try {
      return await _platform.invokeMethod('stopRecording') ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Check if recording
  Future<bool> isRecording() async {
    try {
      return await _platform.invokeMethod('isRecording') ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Optimize memory (kill background processes)
  Future<Map<dynamic, dynamic>> optimizeMemory() async {
    try {
      return await _platform.invokeMethod('optimizeMemory') ?? {};
    } catch (_) {
      return {};
    }
  }

  /// Get memory status
  Future<Map<dynamic, dynamic>> getMemoryStatus() async {
    try {
      return await _platform.invokeMethod('getMemoryStatus') ?? {};
    } catch (_) {
      return {};
    }
  }

  /// Get device info
  Future<Map<dynamic, dynamic>> getDeviceInfo() async {
    try {
      return await _platform.invokeMethod('getDeviceInfo') ?? {};
    } catch (_) {
      return {};
    }
  }

  /// Check usage stats permission
  Future<bool> hasUsageStatsPermission() async {
    try {
      return await _platform.invokeMethod('hasUsageStatsPermission') ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Parse telemetry data from platform channel
  TelemetrySnapshot parseTelemetryData(Map<dynamic, dynamic> data) {
    return TelemetrySnapshot(
      timestamp: data['timestamp'] ?? 0,
      cpu: CpuTelemetry(
        loadPercent: (data['cpuLoad'] ?? 0.0).toDouble(),
        coreFrequenciesMhz: (data['cpuFreqs'] as List<dynamic>?)
            ?.map((e) => (e as num).toInt())
            .toList() ?? [],
        coreCount: (data['cpuFreqs'] as List<dynamic>?)?.length ?? 0,
      ),
      gpu: GpuTelemetry(
        usagePercent: data['gpuUsage'] ?? -1,
        frequencyMhz: data['gpuFreq'] ?? 0,
        vendorName: data['gpuVendor'] ?? 'Unknown',
        available: data['gpuAvailable'] ?? false,
      ),
      memory: MemoryTelemetry(
        totalMb: ((data['memoryTotal'] ?? 0) / 1024).round(),
        availableMb: ((data['memoryAvailable'] ?? 0) / 1024).round(),
        usedMb: ((data['memoryTotal'] ?? 0) - (data['memoryAvailable'] ?? 0)) ~/ 1024,
        usedPercent: data['memoryTotal'] != null && data['memoryTotal'] > 0
            ? ((data['memoryTotal'] - (data['memoryAvailable'] ?? 0)) / data['memoryTotal'] * 100)
            : 0.0,
      ),
      thermalZones: (data['thermalZones'] as List<dynamic>?)
          ?.map((z) => ThermalZone(
            id: z['id'] ?? 0,
            name: z['name'] ?? 'Unknown',
            type: z['type'] ?? 'unknown',
            temperatureC: (z['temp'] ?? 0) / 1000.0,
          ))
          .toList() ?? [],
      thermalThrottling: data['thermalThrottling'] ?? false,
      batteryTempC: (data['batteryTemp'] ?? 0) / 1000.0,
      batteryLevelPercent: data['batteryLevel'] ?? 0,
    );
  }

  /// Parse frame metrics from platform channel
  FrameMetrics parseFrameMetrics(Map<dynamic, dynamic> data) {
    return FrameMetrics(
      currentFps: (data['currentFps'] ?? 0.0).toDouble(),
      averageFps: (data['averageFps'] ?? 0.0).toDouble(),
      onePercentLow: (data['onePercentLow'] ?? 0.0).toDouble(),
      pointOnePercentLow: (data['pointOnePercentLow'] ?? 0.0).toDouble(),
      stutterCount: data['stutterCount'] ?? 0,
      totalFrames: data['totalFrames'] ?? 0,
      frameVariance: (data['frameVariance'] ?? 0.0).toDouble(),
      lastFrameTimeMs: (data['lastFrameTimeMs'] ?? 0.0).toDouble(),
      frameDropped: data['frameDropped'] ?? false,
      targetRefreshRate: data['targetRefreshRate'] ?? 60,
    );
  }
}
