import 'package:freezed_annotation/freezed_annotation.dart';

part 'telemetry_models.freezed.dart';
part 'telemetry_models.g.dart';

/// CPU telemetry snapshot
@freezed
class CpuTelemetry with _$CpuTelemetry {
  const factory CpuTelemetry({
    @Default(0.0) double loadPercent,
    @Default(<int>[]) List<int> coreFrequenciesMhz,
    @Default(0) int coreCount,
    @Default(false) bool throttling,
  }) = _CpuTelemetry;

  factory CpuTelemetry.fromJson(Map<String, dynamic> json) =>
      _$CpuTelemetryFromJson(json);
}

/// GPU telemetry snapshot
@freezed
class GpuTelemetry with _$GpuTelemetry {
  const factory GpuTelemetry({
    @Default(-1) int usagePercent,
    @Default(0) int frequencyMhz,
    @Default('Unknown') String vendorName,
    @Default(false) bool available,
  }) = _GpuTelemetry;

  factory GpuTelemetry.fromJson(Map<String, dynamic> json) =>
      _$GpuTelemetryFromJson(json);
}

/// Memory telemetry snapshot
@freezed
class MemoryTelemetry with _$MemoryTelemetry {
  const factory MemoryTelemetry({
    @Default(0) int totalMb,
    @Default(0) int availableMb,
    @Default(0) int usedMb,
    @Default(0) int cachedMb,
    @Default(0.0) double usedPercent,
  }) = _MemoryTelemetry;

  factory MemoryTelemetry.fromJson(Map<String, dynamic> json) =>
      _$MemoryTelemetryFromJson(json);
}

/// Thermal zone data
@freezed
class ThermalZone with _$ThermalZone {
  const factory ThermalZone({
    @Default(0) int id,
    @Default('Unknown') String name,
    @Default('unknown') String type,
    @Default(0.0) double temperatureC,
    @Default(0.0) double tripPointC,
    @Default(false) bool isCritical,
  }) = _ThermalZone;

  factory ThermalZone.fromJson(Map<String, dynamic> json) =>
      _$ThermalZoneFromJson(json);
}

/// Complete telemetry snapshot
@freezed
class TelemetrySnapshot with _$TelemetrySnapshot {
  const factory TelemetrySnapshot({
    @Default(0) int timestamp,
    @Default(CpuTelemetry()) CpuTelemetry cpu,
    @Default(GpuTelemetry()) GpuTelemetry gpu,
    @Default(MemoryTelemetry()) MemoryTelemetry memory,
    @Default(<ThermalZone>[]) List<ThermalZone> thermalZones,
    @Default(false) bool thermalThrottling,
    @Default(0.0) double batteryTempC,
    @Default(0) int batteryLevelPercent,
  }) = _TelemetrySnapshot;

  factory TelemetrySnapshot.fromJson(Map<String, dynamic> json) =>
      _$TelemetrySnapshotFromJson(json);
}

/// Frame metrics data
@freezed
class FrameMetrics with _$FrameMetrics {
  const factory FrameMetrics({
    @Default(0.0) double currentFps,
    @Default(0.0) double averageFps,
    @Default(0.0) double onePercentLow,
    @Default(0.0) double pointOnePercentLow,
    @Default(0) int stutterCount,
    @Default(0) int totalFrames,
    @Default(0.0) double frameVariance,
    @Default(0.0) double lastFrameTimeMs,
    @Default(16.67) double targetFrameTimeMs,
    @Default(false) bool frameDropped,
    @Default(60) int targetRefreshRate,
  }) = _FrameMetrics;

  factory FrameMetrics.fromJson(Map<String, dynamic> json) =>
      _$FrameMetricsFromJson(json);
}

/// Network metrics data
@freezed
class NetworkMetrics with _$NetworkMetrics {
  const factory NetworkMetrics({
    @Default(0.0) double currentPingMs,
    @Default(0.0) double averagePingMs,
    @Default(0.0) double jitterMs,
    @Default(0.0) double packetLossPercent,
    @Default(0.0) double minPingMs,
    @Default(0.0) double maxPingMs,
    @Default(0) int packetsSent,
    @Default(0) int packetsReceived,
    @Default(false) bool isRunning,
    @Default('') String targetHost,
  }) = _NetworkMetrics;

  factory NetworkMetrics.fromJson(Map<String, dynamic> json) =>
      _$NetworkMetricsFromJson(json);
}

/// Game info model
@freezed
class GameInfo with _$GameInfo {
  const factory GameInfo({
    @Default('') String packageName,
    @Default('Unknown') String appName,
    @Default('Other') String category,
    @Default(false) bool isSystemApp,
    @Default('') String versionName,
  }) = _GameInfo;

  factory GameInfo.fromJson(Map<String, dynamic> json) =>
      _$GameInfoFromJson(json);
}

/// App settings
@freezed
class AppSettings with _$AppSettings {
  const factory AppSettings({
    @Default(500) int pollingIntervalMs,
    @Default(true) bool frameTrackingEnabled,
    @Default(true) bool overlayEnabled,
    @Default(true) bool darkMode,
    @Default(true) bool showDecimalFps,
    @Default(60) int targetRefreshRate,
    @Default(100) int overlayUpdateRateMs,
  }) = _AppSettings;

  factory AppSettings.fromJson(Map<String, dynamic> json) =>
      _$AppSettingsFromJson(json);
}
