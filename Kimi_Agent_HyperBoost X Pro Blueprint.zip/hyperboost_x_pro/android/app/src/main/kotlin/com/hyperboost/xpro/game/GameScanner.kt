package com.hyperboost.xpro.game

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Scans device for installed games using multiple detection strategies.
 * Caches results for fast repeated access.
 */
object GameScanner {
    
    private const val TAG = "GameScanner"
    
    // Known game engine package signatures
    private val GAME_ENGINES = setOf(
        "com.epicgames", "com.unity", "com.unreal",
        "cocos2d", "godot", "libgdx"
    )
    
    // Known game publishers (additional heuristic)
    private val GAME_PUBLISHERS = setOf(
        "com.activision", "com.ea", "com.gameloft",
        "com.tencent", "com.konami", "com.capcom",
        "com.squareenix", "com.ubisoft", "com.riotgames",
        "com.supercell", "com.blizzard", "com.miHoYo",
        "com.netease", "com.krafton", "com.pubg"
    )
    
    @Volatile
    private var cachedGames: List<GameInfo>? = null
    
    data class GameInfo(
        val packageName: String,
        val appName: String,
        val icon: android.graphics.drawable.Drawable?,
        val isSystemApp: Boolean,
        val category: String,
        val installTime: Long,
        val lastUpdateTime: Long,
        val versionName: String,
        val flags: Int
    )
    
    suspend fun scanInstalledGames(context: Context): List<GameInfo> = withContext(Dispatchers.IO) {
        cachedGames?.let { return@withContext it }
        
        val pm = context.packageManager
        val games = mutableListOf<GameInfo>()
        
        try {
            val packages = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledPackages(PackageManager.PackageInfo.oflags(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledPackages(0)
            }
            
            for (pkgInfo in packages) {
                val appInfo = pkgInfo.applicationInfo ?: continue
                
                if (isGame(appInfo, pm)) {
                    val gameInfo = GameInfo(
                        packageName = pkgInfo.packageName,
                        appName = pm.getApplicationLabel(appInfo).toString(),
                        icon = appInfo.loadIcon(pm),
                        isSystemApp = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                        category = categorizeGame(appInfo, pm),
                        installTime = pkgInfo.firstInstallTime,
                        lastUpdateTime = pkgInfo.lastUpdateTime,
                        versionName = pkgInfo.versionName ?: "Unknown",
                        flags = appInfo.flags
                    )
                    games.add(gameInfo)
                }
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Game scan failed: ${e.message}")
        }
        
        val sorted = games.sortedBy { it.appName }
        cachedGames = sorted
        sorted
    }
    
    private fun isGame(appInfo: ApplicationInfo, pm: PackageManager): Boolean {
        // Primary: Official game category
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (appInfo.category == ApplicationInfo.CATEGORY_GAME) {
                return true
            }
        }
        
        // Secondary: Package name heuristics
        val pkgLower = appInfo.packageName.lowercase()
        
        // Check game publishers
        if (GAME_PUBLISHERS.any { pkgLower.startsWith(it) }) {
            return true
        }
        
        // Check game engines
        if (GAME_ENGINES.any { pkgLower.contains(it) }) {
            return true
        }
        
        // Tertiary: Check app name for common game keywords
        try {
            val appName = pm.getApplicationLabel(appInfo).toString().lowercase()
            val gameKeywords = listOf("game", "gaming", "play", "battle", "arena", 
                "racing", "shooter", "puzzle", "rpg", "mmo", "fps")
            if (gameKeywords.any { appName.contains(it) }) {
                // Additional check: must not be a system utility
                if ((appInfo.flags and ApplicationInfo.FLAG_SYSTEM) == 0) {
                    return true
                }
            }
        } catch (_: Exception) {}
        
        return false
    }
    
    private fun categorizeGame(appInfo: ApplicationInfo, pm: PackageManager): String {
        val pkgLower = appInfo.packageName.lowercase()
        
        return when {
            pkgLower.contains("battle") || pkgLower.contains("shooter") || 
            pkgLower.contains("fps") || pkgLower.contains("pubg") || 
            pkgLower.contains("cod") -> "Shooter"
            
            pkgLower.contains("moba") || pkgLower.contains("arena") || 
            pkgLower.contains("wildrift") || pkgLower.contains("honor") -> "MOBA"
            
            pkgLower.contains("racing") || pkgLower.contains("race") || 
            pkgLower.contains("asphalt") || pkgLower.contains("needfor") -> "Racing"
            
            pkgLower.contains("rpg") || pkgLower.contains("genshin") || 
            pkgLower.contains("impact") || pkgLower.contains("zenless") -> "RPG"
            
            pkgLower.contains("sports") || pkgLower.contains("fifa") || 
            pkgLower.contains("nba") || pkgLower.contains("pes") -> "Sports"
            
            pkgLower.contains("puzzle") || pkgLower.contains("match") -> "Puzzle"
            
            pkgLower.contains("strategy") || pkgLower.contains("clash") -> "Strategy"
            
            else -> "Other"
        }
    }
    
    fun invalidateCache() {
        cachedGames = null
        Log.i(TAG, "Game cache invalidated")
    }
}
