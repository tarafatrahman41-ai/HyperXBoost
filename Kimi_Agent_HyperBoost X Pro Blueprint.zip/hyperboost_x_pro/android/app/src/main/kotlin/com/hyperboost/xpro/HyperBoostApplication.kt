package com.hyperboost.xpro

import android.app.Application
import android.util.Log
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.engine.FlutterEngineCache
import io.flutter.embedding.engine.dart.DartExecutor

/**
 * Application class for HyperBoost X Pro.
 * Pre-warms Flutter engine for overlay use.
 */
class HyperBoostApplication : Application() {
    
    companion object {
        private const val TAG = "HyperBoostApp"
        const val ENGINE_ID = "hyperboost_engine"
    }
    
    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "HyperBoost X Pro initializing")
        
        // Pre-warm Flutter engine for fast overlay launch
        val flutterEngine = FlutterEngine(this)
        flutterEngine.dartExecutor.executeDartEntrypoint(
            DartExecutor.DartEntrypoint.createDefault()
        )
        FlutterEngineCache.getInstance().put(ENGINE_ID, flutterEngine)
        
        Log.i(TAG, "Flutter engine pre-warmed and cached")
    }
}
