package com.hyperboost.xpro.utils

import android.app.ActivityManager
import android.content.Context
import android.os.Process
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Manages system resources by safely terminating background processes.
 * Uses only public Android APIs - never violates sandbox restrictions.
 */
object ResourceManager {
    
    private const val TAG = "ResourceManager"
    
    data class ProcessInfo(
        val packageName: String,
        val processName: String,
        val pid: Int,
        val importance: Int,
        val memoryKb: Long,
        val isSystem: Boolean
    )
    
    /**
     * Gets list of background processes that can be safely terminated.
     * Filters out system-critical processes and the current app.
     */
    fun getBackgroundProcesses(context: Context): List<ProcessInfo> {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val myPid = Process.myPid()
        val myPackage = context.packageName
        
        val runningApps = am.runningAppProcesses ?: return emptyList()
        
        return runningApps.mapNotNull { proc ->
            // Skip self
            if (proc.pid == myPid) return@mapNotNull null
            if (proc.processName?.startsWith(myPackage) == true) return@mapNotNull null
            
            // Skip system-critical processes
            val isSystem = proc.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_SYSTEM
                    || proc.processName?.startsWith("android.") == true
                    || proc.processName?.startsWith("com.android.") == true
            
            // Only show background/empty processes
            val isBackground = proc.importance >= ActivityManager.RunningAppProcessInfo.IMPORTANCE_BACKGROUND
            
            if (!isBackground) return@mapNotNull null
            
            ProcessInfo(
                packageName = proc.processName ?: "unknown",
                processName = proc.processName ?: "unknown",
                pid = proc.pid,
                importance = proc.importance,
                memoryKb = 0L, // Would need additional lookup
                isSystem = isSystem
            )
        }.filter { !it.isSystem }
    }
    
    /**
     * Safely kills background processes using public API only.
     * Requires KILL_BACKGROUND_PROCESSES permission.
     */
    suspend fun optimizeBackgroundProcesses(context: Context): OptimizationResult = withContext(Dispatchers.IO) {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val myPackage = context.packageName
        
        var killed = 0
        var failed = 0
        val freedMemoryEstimate = 0L // Cannot accurately measure without additional permissions
        
        try {
            val processes = getBackgroundProcesses(context)
            
            for (proc in processes) {
                try {
                    am.killBackgroundProcesses(proc.packageName)
                    killed++
                } catch (e: SecurityException) {
                    Log.w(TAG, "Cannot kill ${proc.packageName}: ${e.message}")
                    failed++
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to kill ${proc.packageName}: ${e.message}")
                    failed++
                }
            }
            
            // Trigger GC suggestion
            System.gc()
            
        } catch (e: Exception) {
            Log.e(TAG, "Optimization failed: ${e.message}")
        }
        
        OptimizationResult(
            processesKilled = killed,
            processesFailed = failed,
            freedMemoryEstimateKb = freedMemoryEstimate,
            success = killed > 0
        )
    }
    
    /**
     * Get current memory status of the device
     */
    fun getMemoryStatus(context: Context): MemoryStatus {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        
        return MemoryStatus(
            totalRam = mi.totalMem,
            availableRam = mi.availMem,
            threshold = mi.threshold,
            lowMemory = mi.lowMemory,
            usedPercent = ((mi.totalMem - mi.availMem).toDouble() / mi.totalMem * 100).toInt()
        )
    }
    
    data class OptimizationResult(
        val processesKilled: Int,
        val processesFailed: Int,
        val freedMemoryEstimateKb: Long,
        val success: Boolean
    )
    
    data class MemoryStatus(
        val totalRam: Long,
        val availableRam: Long,
        val threshold: Long,
        val lowMemory: Boolean,
        val usedPercent: Int
    )
}
