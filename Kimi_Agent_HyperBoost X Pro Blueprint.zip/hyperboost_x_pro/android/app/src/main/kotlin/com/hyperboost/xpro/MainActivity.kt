package com.hyperboost.xpro

import android.content.*
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.util.Log
import androidx.core.content.ContextCompat
import com.hyperboost.xpro.overlay.HyperBoostOverlayService
import com.hyperboost.xpro.recorder.ScreenRecorderService
import com.hyperboost.xpro.service.HyperBoostTelemetryService
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.EventChannel

/**
 * Main Flutter Activity with platform channel handlers for native services.
 */
class MainActivity : FlutterActivity() {
    
    companion object {
        private const val TAG = "MainActivity"
        private const val PLATFORM_CHANNEL = "com.hyperboost.xpro/platform"
        private const val TELEMETRY_CHANNEL = "com.hyperboost.xpro/telemetry"
        private const val REQUEST_OVERLAY = 1001
        private const val REQUEST_RECORD = 1002
        private const val REQUEST_USAGE_STATS = 1003
    }
    
    private var telemetryEventSink: EventChannel.EventSink? = null
    private var frameMetricsEventSink: EventChannel.EventSink? = null
    private var pendingRecordResult: MethodChannel.Result? = null
    
    private val telemetryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                HyperBoostTelemetryService.BROADCAST_TELEMETRY -> {
                    val snapshot = intent.getParcelableExtra<com.hyperboost.xpro.jni.TelemetrySnapshot>(
                        HyperBoostTelemetryService.EXTRA_TELEMETRY_SNAPSHOT)
                    snapshot?.let { 
                        telemetryEventSink?.success(mapOf(
                            "type" to "telemetry",
                            "timestamp" to it.timestamp,
                            "cpuLoad" to it.cpuLoadPercent,
                            "cpuFreqs" to it.cpuCoreFrequencies,
                            "gpuUsage" to it.gpuUsagePercent,
                            "gpuFreq" to it.gpuFrequencyMhz,
                            "gpuVendor" to it.gpuVendorName,
                            "gpuAvailable" to it.gpuAvailable,
                            "memoryTotal" to it.memoryTotalKb,
                            "memoryAvailable" to it.memoryAvailableKb,
                            "thermalThrottling" to it.thermalThrottling,
                            "batteryTemp" to it.batteryTempMilliC,
                            "batteryLevel" to it.batteryLevelPercent,
                            "thermalZones" to it.thermalZones.map { zone ->
                                mapOf("id" to zone.id, "name" to zone.name, 
                                      "temp" to zone.temperatureMilliC, "type" to zone.type)
                            }
                        ))
                    }
                }
                HyperBoostTelemetryService.BROADCAST_FRAME_METRICS -> {
                    val metrics = intent.getParcelableExtra<com.hyperboost.xpro.jni.FrameMetricsData>(
                        HyperBoostTelemetryService.EXTRA_FRAME_METRICS)
                    metrics?.let {
                        frameMetricsEventSink?.success(mapOf(
                            "type" to "frameMetrics",
                            "currentFps" to it.currentFps,
                            "averageFps" to it.averageFps,
                            "onePercentLow" to it.onePercentLow,
                            "pointOnePercentLow" to it.pointOnePercentLow,
                            "stutterCount" to it.stutterCount,
                            "totalFrames" to it.totalFrames,
                            "frameVariance" to it.frameVariance,
                            "lastFrameTimeMs" to it.lastFrameTimeMs,
                            "frameDropped" to it.frameDropped,
                            "targetRefreshRate" to it.targetRefreshRate
                        ))
                    }
                }
            }
        }
    }
    
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        
        // Method channel for commands
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, PLATFORM_CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    // Telemetry Service
                    "startTelemetry" -> {
                        val interval = call.argument<Int>("intervalMs") ?: 500
                        startTelemetryService(interval.toLong())
                        result.success(true)
                    }
                    "stopTelemetry" -> {
                        stopTelemetryService()
                        result.success(true)
                    }
                    "isTelemetryRunning" -> {
                        result.success(HyperBoostTelemetryService.isRunning)
                    }
                    
                    // Overlay
                    "requestOverlayPermission" -> {
                        requestOverlayPermission()
                        result.success(true)
                    }
                    "canDrawOverlays" -> {
                        result.success(Settings.canDrawOverlays(this))
                    }
                    "showOverlay" -> {
                        showOverlay()
                        result.success(true)
                    }
                    "hideOverlay" -> {
                        hideOverlay()
                        result.success(true)
                    }
                    
                    // Screen Recording
                    "startRecording" -> {
                        val outputPath = call.argument<String>("outputPath")
                        val width = call.argument<Int>("width") ?: 1920
                        val height = call.argument<Int>("height") ?: 1080
                        val bitrate = call.argument<Int>("bitrate") ?: 12_000_000
                        val fps = call.argument<Int>("fps") ?: 60
                        pendingRecordResult = result
                        requestScreenRecord(outputPath, width, height, bitrate, fps)
                    }
                    "stopRecording" -> {
                        stopRecording()
                        result.success(true)
                    }
                    "isRecording" -> {
                        result.success(ScreenRecorderService.isRecording)
                    }
                    
                    // Resource Management
                    "optimizeMemory" -> {
                        optimizeMemory(result)
                    }
                    "getMemoryStatus" -> {
                        val status = com.hyperboost.xpro.utils.ResourceManager.getMemoryStatus(this)
                        result.success(mapOf(
                            "totalRam" to status.totalRam,
                            "availableRam" to status.availableRam,
                            "usedPercent" to status.usedPercent,
                            "lowMemory" to status.lowMemory
                        ))
                    }
                    
                    // Permissions
                    "hasUsageStatsPermission" -> {
                        result.success(hasUsageStatsPermission())
                    }
                    "requestUsageStatsPermission" -> {
                        requestUsageStatsPermission()
                        result.success(true)
                    }
                    
                    // Device Info
                    "getDeviceInfo" -> {
                        result.success(getDeviceInfo())
                    }
                    
                    else -> result.notImplemented()
                }
            }
        
        // Event channels for streaming data
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, "${TELEMETRY_CHANNEL}/data")
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                    telemetryEventSink = events
                }
                override fun onCancel(arguments: Any?) {
                    telemetryEventSink = null
                }
            })
        
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, "${TELEMETRY_CHANNEL}/frames")
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                    frameMetricsEventSink = events
                }
                override fun onCancel(arguments: Any?) {
                    frameMetricsEventSink = null
                }
            })
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Register telemetry broadcast receiver
        val filter = IntentFilter().apply {
            addAction(HyperBoostTelemetryService.BROADCAST_TELEMETRY)
            addAction(HyperBoostTelemetryService.BROADCAST_FRAME_METRICS)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(telemetryReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(telemetryReceiver, filter)
        }
    }
    
    private fun startTelemetryService(intervalMs: Long) {
        val intent = Intent(this, HyperBoostTelemetryService::class.java).apply {
            action = HyperBoostTelemetryService.ACTION_START
            putExtra(HyperBoostTelemetryService.EXTRA_POLLING_INTERVAL, intervalMs)
        }
        ContextCompat.startForegroundService(this, intent)
    }
    
    private fun stopTelemetryService() {
        val intent = Intent(this, HyperBoostTelemetryService::class.java).apply {
            action = HyperBoostTelemetryService.ACTION_STOP
        }
        startService(intent)
    }
    
    private fun requestOverlayPermission() {
        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, 
            Uri.parse("package:$packageName"))
        startActivityForResult(intent, REQUEST_OVERLAY)
    }
    
    private fun showOverlay() {
        val intent = Intent(this, HyperBoostOverlayService::class.java).apply {
            action = HyperBoostOverlayService.ACTION_SHOW
        }
        ContextCompat.startForegroundService(this, intent)
    }
    
    private fun hideOverlay() {
        val intent = Intent(this, HyperBoostOverlayService::class.java).apply {
            action = HyperBoostOverlayService.ACTION_HIDE
        }
        startService(intent)
    }
    
    private fun requestScreenRecord(outputPath: String?, width: Int, height: Int, 
                                    bitrate: Int, fps: Int) {
        val projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val intent = projectionManager.createScreenCaptureIntent()
        startActivityForResult(intent, REQUEST_RECORD)
    }
    
    private fun stopRecording() {
        val intent = Intent(this, ScreenRecorderService::class.java).apply {
            action = ScreenRecorderService.ACTION_STOP
        }
        startService(intent)
    }
    
    private fun optimizeMemory(result: MethodChannel.Result) {
        kotlinx.coroutines.GlobalScope.launch(kotlinx.coroutines.Dispatchers.Main) {
            val optimizationResult = com.hyperboost.xpro.utils.ResourceManager.optimizeBackgroundProcesses(this@MainActivity)
            result.success(mapOf(
                "killed" to optimizationResult.processesKilled,
                "failed" to optimizationResult.processesFailed,
                "success" to optimizationResult.success
            ))
        }
    }
    
    private fun hasUsageStatsPermission(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(), packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(), packageName
            )
        }
        return mode == android.app.AppOpsManager.MODE_ALLOWED
    }
    
    private fun requestUsageStatsPermission() {
        val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
        startActivityForResult(intent, REQUEST_USAGE_STATS)
    }
    
    private fun getDeviceInfo(): Map<String, Any> {
        return mapOf(
            "brand" to Build.BRAND,
            "device" to Build.DEVICE,
            "model" to Build.MODEL,
            "manufacturer" to Build.MANUFACTURER,
            "product" to Build.PRODUCT,
            "androidVersion" to Build.VERSION.RELEASE,
            "sdkInt" to Build.VERSION.SDK_INT,
            "hardware" to Build.HARDWARE,
            "board" to Build.BOARD,
            "supportedAbis" to Build.SUPPORTED_ABIS.toList()
        )
    }
    
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        
        when (requestCode) {
            REQUEST_RECORD -> {
                if (resultCode == RESULT_OK && data != null) {
                    val intent = Intent(this, ScreenRecorderService::class.java).apply {
                        action = ScreenRecorderService.ACTION_START
                        putExtra(ScreenRecorderService.EXTRA_RESULT_CODE, resultCode)
                        putExtra(ScreenRecorderService.EXTRA_RESULT_DATA, data)
                    }
                    ContextCompat.startForegroundService(this, intent)
                    pendingRecordResult?.success(true)
                } else {
                    pendingRecordResult?.success(false)
                }
                pendingRecordResult = null
            }
            REQUEST_OVERLAY -> {
                val granted = Settings.canDrawOverlays(this)
                // Could send result back to Flutter
            }
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(telemetryReceiver)
    }
}
