package com.hyperboost.xpro.jni

import android.util.Log

/**
 * JNI Bridge for HyperBoost X Pro Native Layer
 * Provides direct access to hardware telemetry through NDK
 */
object NativeBridge {
    private const val TAG = "NativeBridge"
    
    init {
        try {
            System.loadLibrary("hyperboost_native")
            Log.i(TAG, "Native library loaded successfully")
        } catch (e: UnsatisfiedLinkError) {
            Log.e(TAG, "Failed to load native library: ${e.message}")
        }
    }
    
    // Core lifecycle
    external fun initializeNative()
    external fun startPolling(intervalMs: Long)
    external fun stopPolling()
    external fun nativeDestroy()
    
    // Telemetry data
    external fun getLatestTelemetry(): TelemetryData?
    external fun getCpuCoreFrequencies(): Array<Long>?
    
    // Thermal
    external fun getThermalZoneCount(): Int
    external fun getThermalZoneTemp(zoneIndex: Int): Double
    external fun getThermalZoneName(zoneIndex: Int): String
    
    fun isNativeAvailable(): Boolean {
        return try {
            initializeNative()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Native layer unavailable: ${e.message}")
            false
        }
    }
}

/**
 * Data class representing a single telemetry frame from native layer
 */
data class TelemetryData(
    var timestamp: Long = 0L,
    var cpuLoadPercent: Double = 0.0,
    var gpuUsagePercent: Int = -1,
    var gpuFrequencyMhz: Int = 0,
    var gpuAvailable: Boolean = false,
    var memoryTotalKb: Long = 0L,
    var memoryAvailableKb: Long = 0L,
    var thermalThrottling: Boolean = false
)
