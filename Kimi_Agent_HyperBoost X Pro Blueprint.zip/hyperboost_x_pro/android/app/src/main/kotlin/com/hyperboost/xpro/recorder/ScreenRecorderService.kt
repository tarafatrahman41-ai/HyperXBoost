package com.hyperboost.xpro.recorder

import android.app.*
import android.content.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.Log
import android.view.Surface
import androidx.core.app.NotificationCompat
import com.hyperboost.xpro.MainActivity
import com.hyperboost.xpro.R
import java.io.File
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Hardware-accelerated screen recording using MediaProjection and MediaCodec.
 * Minimizes frame drops by using direct hardware encoder paths.
 */
class ScreenRecorderService : Service() {
    
    companion object {
        private const val TAG = "ScreenRecorder"
        private const val NOTIFICATION_ID = 0x4844
        private const val CHANNEL_ID = "hyperboost_recorder"
        
        const val ACTION_START = "com.hyperboost.xpro.START_RECORDING"
        const val ACTION_STOP = "com.hyperboost.xpro.STOP_RECORDING"
        const val ACTION_PAUSE = "com.hyperboost.xpro.PAUSE_RECORDING"
        const val ACTION_RESUME = "com.hyperboost.xpro.RESUME_RECORDING"
        
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_OUTPUT_PATH = "output_path"
        const val EXTRA_VIDEO_WIDTH = "video_width"
        const val EXTRA_VIDEO_HEIGHT = "video_height"
        const val EXTRA_VIDEO_BITRATE = "video_bitrate"
        const val EXTRA_VIDEO_FPS = "video_fps"
        
        // Default recording settings optimized for gameplay
        private const val DEFAULT_WIDTH = 1920
        private const val DEFAULT_HEIGHT = 1080
        private const val DEFAULT_BITRATE = 12_000_000 // 12 Mbps
        private const val DEFAULT_FPS = 60
        private const val I_FRAME_INTERVAL = 2 // seconds
        
        var isRecording = false
            private set
    }
    
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var mediaRecorder: MediaRecorder? = null
    private var mediaCodec: MediaCodec? = null
    private var inputSurface: Surface? = null
    
    private val isPaused = AtomicBoolean(false)
    private var outputPath: String = ""
    private var videoWidth = DEFAULT_WIDTH
    private var videoHeight = DEFAULT_HEIGHT
    private var videoBitrate = DEFAULT_BITRATE
    private var videoFps = DEFAULT_FPS
    
    private val handlerThread = HandlerThread("RecorderThread").apply { start() }
    private val handler = Handler(handlerThread.looper)
    
    override fun onBind(intent: Intent): IBinder? = null
    
    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "Recorder service created")
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startRecording(intent)
            ACTION_STOP -> stopRecording()
            ACTION_PAUSE -> pauseRecording()
            ACTION_RESUME -> resumeRecording()
        }
        return START_NOT_STICKY
    }
    
    private fun startRecording(intent: Intent) {
        if (isRecording) return
        
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
        val resultData = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
        outputPath = intent.getStringExtra(EXTRA_OUTPUT_PATH) ?: 
            "${getExternalFilesDir(null)?.absolutePath}/recordings/"
        videoWidth = intent.getIntExtra(EXTRA_VIDEO_WIDTH, DEFAULT_WIDTH)
        videoHeight = intent.getIntExtra(EXTRA_VIDEO_HEIGHT, DEFAULT_HEIGHT)
        videoBitrate = intent.getIntExtra(EXTRA_VIDEO_BITRATE, DEFAULT_BITRATE)
        videoFps = intent.getIntExtra(EXTRA_VIDEO_FPS, DEFAULT_FPS)
        
        if (resultCode == -1 || resultData == null) {
            Log.e(TAG, "Invalid MediaProjection data")
            return
        }
        
        startForeground(NOTIFICATION_ID, createRecordingNotification())
        
        val projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)
        
        setupMediaCodec()
        createVirtualDisplay()
        
        isRecording = true
        Log.i(TAG, "Recording started: ${videoWidth}x${videoHeight} @ ${videoFps}fps, ${videoBitrate/1000000}Mbps")
    }
    
    private fun setupMediaCodec() {
        try {
            // Use MediaRecorder for simplicity with hardware acceleration
            mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(this)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }
            
            mediaRecorder?.apply {
                setVideoSource(MediaRecorder.VideoSource.SURFACE)
                setAudioSource(MediaRecorder.AudioSource.INTERNAL)
                
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setVideoEncoder(MediaRecorder.VideoEncoder.H264)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                
                setVideoSize(videoWidth, videoHeight)
                setVideoFrameRate(videoFps)
                setVideoEncodingBitRate(videoBitrate)
                
                val outputFile = File(outputPath, "hyperboost_rec_${System.currentTimeMillis()}.mp4")
                outputFile.parentFile?.mkdirs()
                setOutputFile(outputFile.absolutePath)
                
                setOnErrorListener { _, what, extra ->
                    Log.e(TAG, "MediaRecorder error: what=$what, extra=$extra")
                    stopRecording()
                    true
                }
                
                prepare()
                inputSurface = surface
            }
            
            mediaRecorder?.start()
            
        } catch (e: Exception) {
            Log.e(TAG, "MediaCodec setup failed: ${e.message}")
            fallbackToCodec(e, resultCode = -1, resultData = null)
        }
    }
    
    private fun fallbackToCodec(e: Exception, resultCode: Int, resultData: Intent?) {
        Log.w(TAG, "Falling back to direct MediaCodec: ${e.message}")
        
        try {
            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, videoWidth, videoHeight)
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            format.setInteger(MediaFormat.KEY_BIT_RATE, videoBitrate)
            format.setInteger(MediaFormat.KEY_FRAME_RATE, videoFps)
            format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, I_FRAME_INTERVAL)
            
            mediaCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            mediaCodec?.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = mediaCodec?.createInputSurface()
            mediaCodec?.start()
            
        } catch (e2: Exception) {
            Log.e(TAG, "Fallback codec also failed: ${e2.message}")
            stopRecording()
        }
    }
    
    private fun createVirtualDisplay() {
        val surface = inputSurface ?: return
        
        mediaProjection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopRecording()
            }
        }, handler)
        
        val density = resources.displayMetrics.densityDpi
        
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "HyperBoostRecorder",
            videoWidth, videoHeight, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR or
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION,
            surface, null, handler
        )
    }
    
    private fun stopRecording() {
        isRecording = false
        
        try {
            mediaRecorder?.apply {
                stop()
                reset()
                release()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping MediaRecorder: ${e.message}")
        }
        mediaRecorder = null
        
        try {
            mediaCodec?.stop()
            mediaCodec?.release()
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping MediaCodec: ${e.message}")
        }
        mediaCodec = null
        
        inputSurface?.release()
        inputSurface = null
        
        virtualDisplay?.release()
        virtualDisplay = null
        
        mediaProjection?.stop()
        mediaProjection = null
        
        stopForeground(STOP_FOREGROUND_REMOVE)
        
        Log.i(TAG, "Recording stopped")
    }
    
    private fun pauseRecording() {
        if (!isRecording || isPaused.get()) return
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            mediaRecorder?.pause()
        }
        isPaused.set(true)
        Log.i(TAG, "Recording paused")
    }
    
    private fun resumeRecording() {
        if (!isRecording || !isPaused.get()) return
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            mediaRecorder?.resume()
        }
        isPaused.set(false)
        Log.i(TAG, "Recording resumed")
    }
    
    private fun createRecordingNotification(): Notification {
        val channel = NotificationChannel(
            CHANNEL_ID, "Screen Recorder",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Gameplay recording in progress"
            setShowBadge(false)
        }
        
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(channel)
        
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, ScreenRecorderService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Recording Gameplay")
            .setContentText("Touch to manage recording")
            .setSmallIcon(R.drawable.ic_recording)
            .setContentIntent(pi)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopIntent)
            .setOngoing(true)
            .build()
    }
    
    override fun onDestroy() {
        super.onDestroy()
        stopRecording()
        handlerThread.quitSafely()
        Log.i(TAG, "Recorder service destroyed")
    }
}
