package com.hyperboost.xpro.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.*
import android.util.Log
import android.view.Choreographer
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.hyperboost.xpro.MainActivity
import com.hyperboost.xpro.R
import com.hyperboost.xpro.jni.*
import kotlinx.coroutines.*
import java.io.BufferedReader
import java.io.FileReader
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs

/**
 * Core telemetry foreground service for HyperBoost X Pro.
 * Manages all hardware polling, frame tracking, and data distribution.
 * Runs in isolated :telemetry process to minimize impact on game performance.
 */
class HyperBoostTelemetryService : Service(), Choreographer.FrameCallback {
    
    companion object {
        private const val TAG = "TelemetryService"
        private const val NOTIFICATION_ID = 0x4842 // "HB"
        private const val CHANNEL_ID = "hyperboost_telemetry"
        
        const val ACTION_START = "com.hyperboost.xpro.START_TELEMETRY"
        const val ACTION_STOP = "com.hyperboost.xpro.STOP_TELEMETRY"
        const val ACTION_UPDATE_CONFIG = "com.hyperboost.xpro.UPDATE_CONFIG"
        
        const val EXTRA_POLLING_INTERVAL = "polling_interval_ms"
        const val EXTRA_FRAME_TRACKING = "frame_tracking_enabled"
        
        // Broadcast actions for clients
        const val BROADCAST_TELEMETRY = "com.hyperboost.xpro.TELEMETRY_UPDATE"
        const val BROADCAST_FRAME_METRICS = "com.hyperboost.xpro.FRAME_METRICS"
        const val BROADCAST_NETWORK_METRICS = "com.hyperboost.xpro.NETWORK_METRICS"
        
        const val EXTRA_TELEMETRY_SNAPSHOT = "telemetry_snapshot"
        const val EXTRA_FRAME_METRICS = "frame_metrics"
        const val EXTRA_NETWORK_METRICS = "network_metrics"
        
        // Polling intervals
        const val POLL_FAST = 100L
        const val POLL_NORMAL = 500L
        const val POLL_SLOW = 1000L
        
        @Volatile
        var isRunning = false
            private set
    }
    
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val binder = TelemetryBinder()
    
    // Frame tracking
    private lateinit var choreographer: Choreographer
    private val frameTimes = ArrayDeque<Long>(3600)
    private val frameTimestamps = ArrayDeque<Long>(3600)
    private val lastFrameTimeNanos = AtomicLong(0L)
    private val totalFrames = AtomicLong(0L)
    private val stutterCount = AtomicLong(0L)
    private val frameWindowLock = Object()
    
    // Touch sampling
    private lateinit var sensorManager: SensorManager
    private var touchSamplingStartTime = 0L
    private var touchEventCount = 0
    private var reportedTouchRate = 0
    
    // Configuration
    private var pollingIntervalMs = POLL_NORMAL
    private var frameTrackingEnabled = true
    private var targetRefreshRate = 60
    
    // Listeners
    private val telemetryListeners = mutableListOf<TelemetryListener>()
    
    interface TelemetryListener {
        fun onTelemetryUpdate(snapshot: TelemetrySnapshot)
        fun onFrameMetrics(metrics: FrameMetricsData)
    }
    
    inner class TelemetryBinder : Binder() {
        fun getService(): HyperBoostTelemetryService = this@HyperBoostTelemetryService
    }
    
    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "Telemetry service created")
        
        choreographer = Choreographer.getInstance()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        
        // Detect display refresh rate
        val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val display = windowManager.defaultDisplay
        targetRefreshRate = display.refreshRate.toInt().coerceIn(30, 240)
        Log.i(TAG, "Target refresh rate detected: $targetRefreshRate Hz")
        
        // Initialize native layer
        try {
            NativeBridge.initializeNative()
            Log.i(TAG, "Native telemetry layer initialized")
        } catch (e: Exception) {
            Log.e(TAG, "Native initialization failed: ${e.message}")
        }
    }
    
    override fun onBind(intent: Intent): IBinder = binder
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startTelemetry()
            ACTION_STOP -> stopTelemetry()
            ACTION_UPDATE_CONFIG -> updateConfig(intent)
        }
        return START_STICKY
    }
    
    private fun startTelemetry() {
        if (isRunning) return
        isRunning = true
        
        startForeground(NOTIFICATION_ID, createNotification())
        
        // Start Choreographer frame callback
        if (frameTrackingEnabled) {
            choreographer.postFrameCallback(this)
        }
        
        // Start native hardware polling
        try {
            NativeBridge.startPolling(pollingIntervalMs)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start native polling: ${e.message}")
        }
        
        // Start Kotlin-side telemetry collection
        serviceScope.launch(Dispatchers.Default) {
            collectTelemetryLoop()
        }
        
        // Start frame metrics computation
        serviceScope.launch(Dispatchers.Default) {
            computeFrameMetricsLoop()
        }
        
        Log.i(TAG, "Telemetry started - interval: ${pollingIntervalMs}ms")
    }
    
    private fun stopTelemetry() {
        isRunning = false
        
        choreographer.removeFrameCallback(this)
        
        try {
            NativeBridge.stopPolling()
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping native polling: ${e.message}")
        }
        
        serviceScope.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        
        Log.i(TAG, "Telemetry stopped")
    }
    
    private fun updateConfig(intent: Intent) {
        pollingIntervalMs = intent.getLongExtra(EXTRA_POLLING_INTERVAL, POLL_NORMAL)
        frameTrackingEnabled = intent.getBooleanExtra(EXTRA_FRAME_TRACKING, true)
        
        if (isRunning) {
            // Restart with new config
            try {
                NativeBridge.stopPolling()
                NativeBridge.startPolling(pollingIntervalMs)
            } catch (e: Exception) {
                Log.e(TAG, "Error updating config: ${e.message}")
            }
        }
    }
    
    // Choreographer.FrameCallback implementation
    override fun doFrame(frameTimeNanos: Long) {
        if (!isRunning) return
        
        val last = lastFrameTimeNanos.get()
        if (last > 0) {
            val deltaNanos = frameTimeNanos - last
            val deltaMs = deltaNanos / 1_000_000.0
            
            synchronized(frameWindowLock) {
                if (frameTimes.size >= 3600) {
                    frameTimes.removeFirst()
                    frameTimestamps.removeFirst()
                }
                frameTimes.addLast(deltaMs)
                frameTimestamps.addLast(frameTimeNanos)
            }
            
            totalFrames.incrementAndGet()
            
            // Detect stutter
            val targetFrameTimeMs = 1000.0 / targetRefreshRate
            if (deltaMs > targetFrameTimeMs * 1.5) {
                stutterCount.incrementAndGet()
            }
        }
        
        lastFrameTimeNanos.set(frameTimeNanos)
        
        // Post next callback
        choreographer.postFrameCallback(this)
    }
    
    private suspend fun collectTelemetryLoop() {
        while (isActive && isRunning) {
            try {
                val snapshot = buildTelemetrySnapshot()
                broadcastTelemetry(snapshot)
                
                delay(pollingIntervalMs)
            } catch (e: CancellationException) {
                break
            } catch (e: Exception) {
                Log.e(TAG, "Telemetry collection error: ${e.message}")
                delay(pollingIntervalMs)
            }
        }
    }
    
    private suspend fun computeFrameMetricsLoop() {
        while (isActive && isRunning) {
            try {
                val metrics = computeFrameMetrics()
                broadcastFrameMetrics(metrics)
                
                delay(500) // Update FPS display at 2Hz
            } catch (e: CancellationException) {
                break
            } catch (e: Exception) {
                Log.e(TAG, "Frame metrics error: ${e.message}")
                delay(500)
            }
        }
    }
    
    private fun buildTelemetrySnapshot(): TelemetrySnapshot {
        val timestamp = System.currentTimeMillis()
        
        // Get native telemetry
        val nativeData = try {
            NativeBridge.getLatestTelemetry()
        } catch (e: Exception) {
            null
        }
        
        // Read CPU core frequencies
        val cpuFreqs = try {
            NativeBridge.getCpuCoreFrequencies()?.toList() ?: emptyList()
        } catch (e: Exception) {
            readCpuFrequenciesFallback()
        }
        
        // Read memory info
        val memInfo = readMemoryInfo()
        
        // Read thermal zones
        val thermalZones = readThermalZones()
        val isThrottling = detectThermalThrottling(thermalZones, cpuFreqs)
        
        // Battery info
        val (batteryTemp, batteryLevel) = readBatteryInfo()
        
        return TelemetrySnapshot(
            timestamp = timestamp,
            cpuLoadPercent = nativeData?.cpuLoadPercent ?: readCpuLoadFallback(),
            cpuCoreFrequencies = cpuFreqs,
            cpuCoreCount = cpuFreqs.size,
            gpuUsagePercent = nativeData?.gpuUsagePercent ?: -1,
            gpuFrequencyMhz = nativeData?.gpuFrequencyMhz ?: 0,
            gpuVendorName = detectGpuVendor(),
            gpuAvailable = nativeData?.gpuAvailable ?: false,
            memoryTotalKb = memInfo.first,
            memoryAvailableKb = nativeData?.memoryAvailableKb ?: memInfo.second,
            memoryCachedKb = 0L,
            memoryActiveKb = 0L,
            thermalZones = thermalZones,
            thermalThrottling = isThrottling,
            batteryTempMilliC = batteryTemp,
            batteryLevelPercent = batteryLevel
        )
    }
    
    private fun computeFrameMetrics(): FrameMetricsData {
        synchronized(frameWindowLock) {
            val frameList = frameTimes.toList()
            
            if (frameList.isEmpty()) {
                return FrameMetricsData(0.0, 0.0, 0.0, 0.0, 0, 0, 0.0, 0.0, 
                    1000.0 / targetRefreshRate, false, targetRefreshRate)
            }
            
            val sortedFrames = frameList.sortedDescending()
            val totalTime = frameList.sum()
            val avgFrameTime = totalTime / frameList.size
            
            // Current FPS (last frame)
            val currentFps = 1000.0 / frameList.last()
            
            // Average FPS
            val avgFps = 1000.0 / avgFrameTime
            
            // 1% Low
            val onePercentCount = (frameList.size / 100).coerceAtLeast(1)
            val onePercentAvg = sortedFrames.take(onePercentCount).average()
            val onePercentLow = 1000.0 / onePercentAvg
            
            // 0.1% Low
            val pointOneCount = (frameList.size / 1000).coerceAtLeast(1)
            val pointOneAvg = sortedFrames.take(pointOneCount).average()
            val pointOnePercentLow = 1000.0 / pointOneAvg
            
            // Variance
            val variance = if (frameList.size >= 2) {
                val mean = avgFrameTime
                frameList.map { (it - mean) * (it - mean) }.average()
            } else 0.0
            
            // Stutter detection
            val targetFrameTime = 1000.0 / targetRefreshRate
            val lastFrameDropped = frameList.last() > targetFrameTime * 1.5
            
            return FrameMetricsData(
                currentFps = currentFps.coerceIn(0.0, 999.0),
                averageFps = avgFps.coerceIn(0.0, 999.0),
                onePercentLow = onePercentLow.coerceIn(0.0, 999.0),
                pointOnePercentLow = pointOnePercentLow.coerceIn(0.0, 999.0),
                stutterCount = stutterCount.get().toInt(),
                totalFrames = totalFrames.get().toInt(),
                frameVariance = variance,
                lastFrameTimeMs = frameList.last(),
                targetFrameTimeMs = targetFrameTime,
                frameDropped = lastFrameDropped,
                targetRefreshRate = targetRefreshRate
            )
        }
    }
    
    private fun readCpuFrequenciesFallback(): List<Long> {
        val freqs = mutableListOf<Long>()
        try {
            val cpuDir = java.io.File("/sys/devices/system/cpu/")
            cpuDir.listFiles { f -> f.name.matches(Regex("cpu[0-9]+")) }?.forEach { cpu ->
                val freqFile = java.io.File(cpu, "cpufreq/scaling_cur_freq")
                if (freqFile.exists()) {
                    val freq = freqFile.readText().trim().toLongOrNull() ?: 0L
                    freqs.add(freq)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "CPU freq fallback failed: ${e.message}")
        }
        return freqs
    }
    
    private fun readCpuLoadFallback(): Double {
        return try {
            val reader = BufferedReader(FileReader("/proc/stat"))
            val line = reader.readLine() ?: return -1.0
            reader.close()
            
            val parts = line.split(Regex("\\s+"))
            if (parts.size < 8) return -1.0
            
            val user = parts[1].toLongOrNull() ?: 0L
            val nice = parts[2].toLongOrNull() ?: 0L
            val system = parts[3].toLongOrNull() ?: 0L
            val idle = parts[4].toLongOrNull() ?: 0L
            val iowait = parts[5].toLongOrNull() ?: 0L
            val irq = parts[6].toLongOrNull() ?: 0L
            val softirq = parts[7].toLongOrNull() ?: 0L
            
            val total = user + nice + system + idle + iowait + irq + softirq
            val active = total - idle
            
            if (total > 0) 100.0 * active / total else 0.0
        } catch (e: Exception) {
            -1.0
        }
    }
    
    private fun readMemoryInfo(): Pair<Long, Long> {
        return try {
            val reader = BufferedReader(FileReader("/proc/meminfo"))
            var total = 0L
            var available = 0L
            
            reader.useLines { lines ->
                lines.forEach { line ->
                    when {
                        line.startsWith("MemTotal:") -> 
                            total = line.filter { it.isDigit() }.toLongOrNull() ?: 0L
                        line.startsWith("MemAvailable:") -> 
                            available = line.filter { it.isDigit() }.toLongOrNull() ?: 0L
                    }
                }
            }
            
            Pair(total, available)
        } catch (e: Exception) {
            Pair(0L, 0L)
        }
    }
    
    private fun readThermalZones(): List<ThermalZoneData> {
        val zones = mutableListOf<ThermalZoneData>()
        try {
            val thermalDir = java.io.File("/sys/class/thermal/")
            thermalDir.listFiles { f -> f.name.startsWith("thermal_zone") }?.forEach { zone ->
                try {
                    val id = zone.name.filter { it.isDigit() }.toIntOrNull() ?: return@forEach
                    val type = java.io.File(zone, "type").readText().trim()
                    val temp = java.io.File(zone, "temp").readText().trim().toIntOrNull() ?: 0
                    
                    zones.add(ThermalZoneData(
                        id = id,
                        name = "${type}_$id",
                        type = type,
                        temperatureMilliC = temp,
                        tripPointMilliC = 0,
                        isCritical = false
                    ))
                } catch (e: Exception) {
                    // Skip unreadable zones
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Thermal zone read failed: ${e.message}")
        }
        return zones
    }
    
    private fun detectThermalThrottling(thermalZones: List<ThermalZoneData>, 
                                       cpuFreqs: List<Long>): Boolean {
        // Simplified throttling detection
        val criticalZones = thermalZones.count { 
            (it.type.contains("cpu", ignoreCase = true) && it.temperatureMilliC > 85000) ||
            (it.type.contains("gpu", ignoreCase = true) && it.temperatureMilliC > 80000)
        }
        return criticalZones >= 2
    }
    
    private fun readBatteryInfo(): Pair<Int, Int> {
        val intent = registerReceiver(null, android.content.IntentFilter(
            android.content.Intent.ACTION_BATTERY_CHANGED))
        
        val temp = intent?.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val level = intent?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val scale = intent?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100) ?: 100
        
        return Pair(temp, (level * 100 / scale))
    }
    
    private fun detectGpuVendor(): String {
        return try {
            val renderer = android.opengl.GLES20.glGetString(android.opengl.GLES20.GL_RENDERER) ?: "Unknown"
            when {
                renderer.contains("Adreno", ignoreCase = true) -> "Qualcomm Adreno"
                renderer.contains("Mali", ignoreCase = true) -> "ARM Mali"
                renderer.contains("PowerVR", ignoreCase = true) -> "Imagination PowerVR"
                else -> renderer
            }
        } catch (e: Exception) {
            "Unknown"
        }
    }
    
    private fun broadcastTelemetry(snapshot: TelemetrySnapshot) {
        val intent = Intent(BROADCAST_TELEMETRY).apply {
            putExtra(EXTRA_TELEMETRY_SNAPSHOT, snapshot)
            setPackage(packageName)
        }
        sendBroadcast(intent)
        
        // Notify local listeners
        telemetryListeners.forEach { 
            try { it.onTelemetryUpdate(snapshot) } catch (_: Exception) {} 
        }
    }
    
    private fun broadcastFrameMetrics(metrics: FrameMetricsData) {
        val intent = Intent(BROADCAST_FRAME_METRICS).apply {
            putExtra(EXTRA_FRAME_METRICS, metrics)
            setPackage(packageName)
        }
        sendBroadcast(intent)
        
        telemetryListeners.forEach { 
            try { it.onFrameMetrics(metrics) } catch (_: Exception) {} 
        }
    }
    
    fun addListener(listener: TelemetryListener) {
        telemetryListeners.add(listener)
    }
    
    fun removeListener(listener: TelemetryListener) {
        telemetryListeners.remove(listener)
    }
    
    private fun createNotification(): Notification {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "HyperBoost Telemetry",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Real-time gaming performance monitoring"
            setShowBadge(false)
        }
        
        val notificationManager = getSystemService(NotificationManager::class.java)
        notificationManager.createNotificationChannel(channel)
        
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("HyperBoost X Pro")
            .setContentText("Telemetry active - monitoring performance")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }
    
    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        serviceScope.cancel()
        try {
            NativeBridge.nativeDestroy()
        } catch (e: Exception) {
            Log.e(TAG, "Error destroying native resources: ${e.message}")
        }
        Log.i(TAG, "Telemetry service destroyed")
    }
}
