package com.hyperboost.xpro.game

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.hyperboost.xpro.service.HyperBoostTelemetryService

/**
 * Boot receiver for automatic game detection and service startup
 */
class GameLaunchReceiver : BroadcastReceiver() {
    
    companion object {
        private const val TAG = "GameLaunchReceiver"
    }
    
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED -> {
                Log.i(TAG, "Boot completed - initializing game detection")
                // Could auto-start telemetry here if user enabled it
            }
            Intent.ACTION_PACKAGE_ADDED, Intent.ACTION_PACKAGE_REMOVED -> {
                // Invalidate game cache
                GameScanner.invalidateCache()
            }
        }
    }
}
