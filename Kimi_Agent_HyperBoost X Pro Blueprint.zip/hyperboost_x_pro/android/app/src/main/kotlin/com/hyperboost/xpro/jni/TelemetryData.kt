package com.hyperboost.xpro.jni

import android.os.Parcel
import android.os.Parcelable

/**
 * Immutable telemetry data snapshot from native hardware polling
 */
data class TelemetrySnapshot(
    val timestamp: Long,
    val cpuLoadPercent: Double,
    val cpuCoreFrequencies: List<Long>,
    val cpuCoreCount: Int,
    val gpuUsagePercent: Int,
    val gpuFrequencyMhz: Int,
    val gpuVendorName: String,
    val gpuAvailable: Boolean,
    val memoryTotalKb: Long,
    val memoryAvailableKb: Long,
    val memoryCachedKb: Long,
    val memoryActiveKb: Long,
    val thermalZones: List<ThermalZoneData>,
    val thermalThrottling: Boolean,
    val batteryTempMilliC: Int,
    val batteryLevelPercent: Int
) : Parcelable {
    
    constructor(parcel: Parcel) : this(
        timestamp = parcel.readLong(),
        cpuLoadPercent = parcel.readDouble(),
        cpuCoreFrequencies = parcel.createLongArray()?.toList() ?: emptyList(),
        cpuCoreCount = parcel.readInt(),
        gpuUsagePercent = parcel.readInt(),
        gpuFrequencyMhz = parcel.readInt(),
        gpuVendorName = parcel.readString() ?: "Unknown",
        gpuAvailable = parcel.readByte() != 0.toByte(),
        memoryTotalKb = parcel.readLong(),
        memoryAvailableKb = parcel.readLong(),
        memoryCachedKb = parcel.readLong(),
        memoryActiveKb = parcel.readLong(),
        thermalZones = parcel.createTypedArrayList(ThermalZoneData.CREATOR) ?: emptyList(),
        thermalThrottling = parcel.readByte() != 0.toByte(),
        batteryTempMilliC = parcel.readInt(),
        batteryLevelPercent = parcel.readInt()
    )
    
    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeLong(timestamp)
        parcel.writeDouble(cpuLoadPercent)
        parcel.writeLongArray(cpuCoreFrequencies.toLongArray())
        parcel.writeInt(cpuCoreCount)
        parcel.writeInt(gpuUsagePercent)
        parcel.writeInt(gpuFrequencyMhz)
        parcel.writeString(gpuVendorName)
        parcel.writeByte(if (gpuAvailable) 1 else 0)
        parcel.writeLong(memoryTotalKb)
        parcel.writeLong(memoryAvailableKb)
        parcel.writeLong(memoryCachedKb)
        parcel.writeLong(memoryActiveKb)
        parcel.writeTypedList(thermalZones)
        parcel.writeByte(if (thermalThrottling) 1 else 0)
        parcel.writeInt(batteryTempMilliC)
        parcel.writeInt(batteryLevelPercent)
    }
    
    override fun describeContents(): Int = 0
    
    companion object CREATOR : Parcelable.Creator<TelemetrySnapshot> {
        override fun createFromParcel(parcel: Parcel): TelemetrySnapshot = TelemetrySnapshot(parcel)
        override fun newArray(size: Int): Array<TelemetrySnapshot?> = arrayOfNulls(size)
    }
}

data class ThermalZoneData(
    val id: Int,
    val name: String,
    val type: String,
    val temperatureMilliC: Int,
    val tripPointMilliC: Int,
    val isCritical: Boolean
) : Parcelable {
    
    constructor(parcel: Parcel) : this(
        id = parcel.readInt(),
        name = parcel.readString() ?: "",
        type = parcel.readString() ?: "",
        temperatureMilliC = parcel.readInt(),
        tripPointMilliC = parcel.readInt(),
        isCritical = parcel.readByte() != 0.toByte()
    )
    
    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeInt(id)
        parcel.writeString(name)
        parcel.writeString(type)
        parcel.writeInt(temperatureMilliC)
        parcel.writeInt(tripPointMilliC)
        parcel.writeByte(if (isCritical) 1 else 0)
    }
    
    override fun describeContents(): Int = 0
    
    companion object CREATOR : Parcelable.Creator<ThermalZoneData> {
        override fun createFromParcel(parcel: Parcel): ThermalZoneData = ThermalZoneData(parcel)
        override fun newArray(size: Int): Array<ThermalZoneData?> = arrayOfNulls(size)
    }
}

data class FrameMetricsData(
    val currentFps: Double,
    val averageFps: Double,
    val onePercentLow: Double,
    val pointOnePercentLow: Double,
    val stutterCount: Int,
    val totalFrames: Int,
    val frameVariance: Double,
    val lastFrameTimeMs: Double,
    val targetFrameTimeMs: Double,
    val frameDropped: Boolean,
    val targetRefreshRate: Int
) : Parcelable {
    
    constructor(parcel: Parcel) : this(
        currentFps = parcel.readDouble(),
        averageFps = parcel.readDouble(),
        onePercentLow = parcel.readDouble(),
        pointOnePercentLow = parcel.readDouble(),
        stutterCount = parcel.readInt(),
        totalFrames = parcel.readInt(),
        frameVariance = parcel.readDouble(),
        lastFrameTimeMs = parcel.readDouble(),
        targetFrameTimeMs = parcel.readDouble(),
        frameDropped = parcel.readByte() != 0.toByte(),
        targetRefreshRate = parcel.readInt()
    )
    
    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeDouble(currentFps)
        parcel.writeDouble(averageFps)
        parcel.writeDouble(onePercentLow)
        parcel.writeDouble(pointOnePercentLow)
        parcel.writeInt(stutterCount)
        parcel.writeInt(totalFrames)
        parcel.writeDouble(frameVariance)
        parcel.writeDouble(lastFrameTimeMs)
        parcel.writeDouble(targetFrameTimeMs)
        parcel.writeByte(if (frameDropped) 1 else 0)
        parcel.writeInt(targetRefreshRate)
    }
    
    override fun describeContents(): Int = 0
    
    companion object CREATOR : Parcelable.Creator<FrameMetricsData> {
        override fun createFromParcel(parcel: Parcel): FrameMetricsData = FrameMetricsData(parcel)
        override fun newArray(size: Int): Array<FrameMetricsData?> = arrayOfNulls(size)
    }
}

data class NetworkMetricsData(
    val currentPingMs: Double,
    val averagePingMs: Double,
    val jitterMs: Double,
    val packetLossPercent: Double,
    val minPingMs: Double,
    val maxPingMs: Double,
    val packetsSent: Int,
    val packetsReceived: Int,
    val isRunning: Boolean,
    val targetHost: String
) : Parcelable {
    
    constructor(parcel: Parcel) : this(
        currentPingMs = parcel.readDouble(),
        averagePingMs = parcel.readDouble(),
        jitterMs = parcel.readDouble(),
        packetLossPercent = parcel.readDouble(),
        minPingMs = parcel.readDouble(),
        maxPingMs = parcel.readDouble(),
        packetsSent = parcel.readInt(),
        packetsReceived = parcel.readInt(),
        isRunning = parcel.readByte() != 0.toByte(),
        targetHost = parcel.readString() ?: ""
    )
    
    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeDouble(currentPingMs)
        parcel.writeDouble(averagePingMs)
        parcel.writeDouble(jitterMs)
        parcel.writeDouble(packetLossPercent)
        parcel.writeDouble(minPingMs)
        parcel.writeDouble(maxPingMs)
        parcel.writeInt(packetsSent)
        parcel.writeInt(packetsReceived)
        parcel.writeByte(if (isRunning) 1 else 0)
        parcel.writeString(targetHost)
    }
    
    override fun describeContents(): Int = 0
    
    companion object CREATOR : Parcelable.Creator<NetworkMetricsData> {
        override fun createFromParcel(parcel: Parcel): NetworkMetricsData = NetworkMetricsData(parcel)
        override fun newArray(size: Int): Array<NetworkMetricsData?> = arrayOfNulls(size)
    }
}
