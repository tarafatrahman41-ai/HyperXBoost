package com.hyperboost.xpro.overlay

import android.app.*
import android.content.*
import android.graphics.*
import android.os.*
import android.util.Log
import android.view.*
import android.widget.FrameLayout
import androidx.core.app.NotificationCompat
import com.hyperboost.xpro.MainActivity
import com.hyperboost.xpro.R
import com.hyperboost.xpro.jni.*
import com.hyperboost.xpro.service.HyperBoostTelemetryService
import io.flutter.embedding.android.FlutterView
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.engine.FlutterEngineCache
import io.flutter.embedding.engine.dart.DartExecutor
import io.flutter.plugin.common.MethodChannel

/**
 * Floating overlay service displaying real-time telemetry on top of games.
 * Uses FlutterView for high-performance rendering with minimal overhead.
 */
class HyperBoostOverlayService : Service(), HyperBoostTelemetryService.TelemetryListener {
    
    companion object {
        private const val TAG = "OverlayService"
        private const val NOTIFICATION_ID = 0x4843
        private const val CHANNEL_ID = "hyperboost_overlay"
        private const val OVERLAY_CHANNEL = "com.hyperboost.xpro/overlay"
        
        const val ACTION_SHOW = "com.hyperboost.xpro.SHOW_OVERLAY"
        const val ACTION_HIDE = "com.hyperboost.xpro.HIDE_OVERLAY"
        const val ACTION_UPDATE_DATA = "com.hyperboost.xpro.UPDATE_OVERLAY"
        
        var isOverlayActive = false
            private set
    }
    
    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var flutterView: FlutterView? = null
    private var flutterEngine: FlutterEngine? = null
    private var methodChannel: MethodChannel? = null
    
    private val params = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = 16
        y = 100
        width = 380
        height = 200
    }
    
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                HyperBoostTelemetryService.BROADCAST_TELEMETRY -> {
                    val snapshot = intent.getParcelableExtra<TelemetrySnapshot>(
                        HyperBoostTelemetryService.EXTRA_TELEMETRY_SNAPSHOT)
                    snapshot?.let { updateTelemetryData(it) }
                }
                HyperBoostTelemetryService.BROADCAST_FRAME_METRICS -> {
                    val metrics = intent.getParcelableExtra<FrameMetricsData>(
                        HyperBoostTelemetryService.EXTRA_FRAME_METRICS)
                    metrics?.let { updateFrameMetrics(it) }
                }
            }
        }
    }
    
    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "Overlay service created")
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        
        // Initialize Flutter engine for overlay
        initFlutterEngine()
        
        // Register broadcast receiver
        val filter = IntentFilter().apply {
            addAction(HyperBoostTelemetryService.BROADCAST_TELEMETRY)
            addAction(HyperBoostTelemetryService.BROADCAST_FRAME_METRICS)
        }
        registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
    }
    
    override fun onBind(intent: Intent): IBinder? = null
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SHOW -> showOverlay()
            ACTION_HIDE -> hideOverlay()
        }
        return START_STICKY
    }
    
    private fun initFlutterEngine() {
        flutterEngine = FlutterEngineCache.getInstance().get("overlay_engine") ?: run {
            val engine = FlutterEngine(this)
            engine.dartExecutor.executeDartEntrypoint(
                DartExecutor.DartEntrypoint.createDefault()
            )
            FlutterEngineCache.getInstance().put("overlay_engine", engine)
            engine
        }
        
        methodChannel = MethodChannel(flutterEngine!!.dartExecutor.binaryMessenger, OVERLAY_CHANNEL)
        methodChannel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "getOverlayConfig" -> result.success(mapOf(
                    "width" to params.width,
                    "height" to params.height,
                    "positionX" to params.x,
                    "positionY" to params.y,
                    "transparency" to 0.85
                ))
                "moveOverlay" -> {
                    val x = call.argument<Int>("x") ?: params.x
                    val y = call.argument<Int>("y") ?: params.y
                    moveOverlay(x, y)
                    result.success(null)
                }
                "resizeOverlay" -> {
                    val w = call.argument<Int>("width") ?: params.width
                    val h = call.argument<Int>("height") ?: params.height
                    resizeOverlay(w, h)
                    result.success(null)
                }
                "closeOverlay" -> {
                    hideOverlay()
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }
    }
    
    private fun showOverlay() {
        if (overlayView != null) return
        
        startForeground(NOTIFICATION_ID, createNotification())
        
        flutterView = FlutterView(this).apply {
            attachToFlutterEngine(flutterEngine!!)
        }
        
        overlayView = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            addView(flutterView, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            ))
        }
        
        windowManager?.addView(overlayView, params)
        isOverlayActive = true
        
        Log.i(TAG, "Overlay shown")
    }
    
    private fun hideOverlay() {
        if (overlayView != null) {
            windowManager?.removeView(overlayView)
            flutterView?.detachFromFlutterEngine()
            overlayView = null
            flutterView = null
        }
        
        stopForeground(STOP_FOREGROUND_REMOVE)
        isOverlayActive = false
        
        Log.i(TAG, "Overlay hidden")
    }
    
    private fun moveOverlay(x: Int, y: Int) {
        params.x = x
        params.y = y
        if (overlayView != null) {
            windowManager?.updateViewLayout(overlayView, params)
        }
    }
    
    private fun resizeOverlay(width: Int, height: Int) {
        params.width = width
        params.height = height
        if (overlayView != null) {
            windowManager?.updateViewLayout(overlayView, params)
        }
    }
    
    private fun updateTelemetryData(snapshot: TelemetrySnapshot) {
        val data = mapOf(
            "cpuLoad" to snapshot.cpuLoadPercent,
            "cpuFreqs" to snapshot.cpuCoreFrequencies,
            "gpuUsage" to snapshot.gpuUsagePercent,
            "gpuFreq" to snapshot.gpuFrequencyMhz,
            "memoryTotal" to snapshot.memoryTotalKb,
            "memoryAvailable" to snapshot.memoryAvailableKb,
            "thermalThrottling" to snapshot.thermalThrottling,
            "batteryTemp" to snapshot.batteryTempMilliC / 1000.0,
            "timestamp" to snapshot.timestamp
        )
        
        methodChannel?.invokeMethod("updateTelemetry", data)
    }
    
    private fun updateFrameMetrics(metrics: FrameMetricsData) {
        val data = mapOf(
            "currentFps" to metrics.currentFps,
            "averageFps" to metrics.averageFps,
            "onePercentLow" to metrics.onePercentLow,
            "pointOnePercentLow" to metrics.pointOnePercentLow,
            "stutterCount" to metrics.stutterCount,
            "frameDropped" to metrics.frameDropped,
            "targetRefreshRate" to metrics.targetRefreshRate
        )
        
        methodChannel?.invokeMethod("updateFrameMetrics", data)
    }
    
    private fun createNotification(): Notification {
        val channel = NotificationChannel(
            CHANNEL_ID, "HyperBoost Overlay",
            NotificationManager.IMPORTANCE_MIN
        ).apply {
            description = "Floating performance overlay"
            setShowBadge(false)
        }
        
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(channel)
        
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("HyperBoost Overlay")
            .setContentText("Performance overlay active")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pi)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }
    
    override fun onTelemetryUpdate(snapshot: TelemetrySnapshot) {
        updateTelemetryData(snapshot)
    }
    
    override fun onFrameMetrics(metrics: FrameMetricsData) {
        updateFrameMetrics(metrics)
    }
    
    override fun onDestroy() {
        super.onDestroy()
        hideOverlay()
        try {
            unregisterReceiver(receiver)
        } catch (_: Exception) {}
        Log.i(TAG, "Overlay service destroyed")
    }
}
