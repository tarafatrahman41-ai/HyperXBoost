#pragma once

#include <string>
#include <vector>
#include <chrono>
#include <atomic>
#include <mutex>
#include <thread>
#include <condition_variable>

namespace hyperboost {

struct PingResult {
    double rttMs;
    bool success;
    uint32_t sequence;
    std::chrono::steady_clock::time_point timestamp;
};

struct NetworkMetrics {
    double currentPingMs;
    double averagePingMs;
    double jitterMs;
    double packetLossPercent;
    double minPingMs;
    double maxPingMs;
    uint32_t packetsSent;
    uint32_t packetsReceived;
    bool dnsResolutionSuccess;
    double dnsLatencyMs;
};

class PingAnalyzer {
public:
    PingAnalyzer();
    ~PingAnalyzer();
    
    bool Start(const std::string& host, int intervalMs);
    void Stop();
    NetworkMetrics GetMetrics();
    bool IsRunning() const { return m_running.load(); }
    
private:
    void PingLoop();
    double ExecutePing(const std::string& host);
    void UpdateMetrics(const PingResult& result);
    void CalculateJitter();
    
    std::string m_host;
    std::atomic<int> m_intervalMs{1000};
    std::atomic<bool> m_running{false};
    
    std::thread m_pingThread;
    std::mutex m_metricsMutex;
    
    std::vector<double> m_pingHistory;
    NetworkMetrics m_currentMetrics;
    
    static constexpr size_t MAX_PING_HISTORY = 300; // 5 minutes at 1 ping/sec
};

} // namespace hyperboost
