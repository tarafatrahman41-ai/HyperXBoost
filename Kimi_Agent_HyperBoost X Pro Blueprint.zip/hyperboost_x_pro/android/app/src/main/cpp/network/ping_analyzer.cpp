#include "ping_analyzer.h"
#include <android/log.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip_icmp.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <cstring>
#include <algorithm>
#include <numeric>
#include <cmath>
#include <errno.h>
#include <netdb.h>

#define LOG_TAG "PingAnalyzer"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace hyperboost {

PingAnalyzer::PingAnalyzer() {
    m_currentMetrics = {};
    m_pingHistory.reserve(MAX_PING_HISTORY);
}

PingAnalyzer::~PingAnalyzer() {
    Stop();
}

bool PingAnalyzer::Start(const std::string& host, int intervalMs) {
    if (m_running.exchange(true)) {
        return false; // Already running
    }
    
    m_host = host;
    m_intervalMs.store(intervalMs);
    m_pingHistory.clear();
    m_currentMetrics = {};
    
    m_pingThread = std::thread(&PingAnalyzer::PingLoop, this);
    LOGI("Ping analyzer started - target: %s, interval: %dms", host.c_str(), intervalMs);
    return true;
}

void PingAnalyzer::Stop() {
    m_running.store(false);
    if (m_pingThread.joinable()) {
        m_pingThread.join();
    }
    LOGI("Ping analyzer stopped");
}

NetworkMetrics PingAnalyzer::GetMetrics() {
    std::lock_guard<std::mutex> lock(m_metricsMutex);
    return m_currentMetrics;
}

void PingAnalyzer::PingLoop() {
    pthread_setname_np(pthread_self(), "hb_ping");
    
    uint32_t sequence = 0;
    
    while (m_running.load()) {
        auto start = std::chrono::steady_clock::now();
        
        double rtt = ExecutePing(m_host);
        
        PingResult result;
        result.rttMs = rtt;
        result.success = (rtt >= 0);
        result.sequence = sequence++;
        result.timestamp = std::chrono::steady_clock::now();
        
        UpdateMetrics(result);
        
        // Sleep for remaining interval time
        auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now() - start).count();
        
        int sleepMs = m_intervalMs.load() - static_cast<int>(elapsed);
        if (sleepMs > 0) {
            std::this_thread::sleep_for(std::chrono::milliseconds(sleepMs));
        }
    }
}

double PingAnalyzer::ExecutePing(const std::string& host) {
    int sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_ICMP);
    if (sockfd < 0) {
        // Fallback to system ping command if raw socket not available
        sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd < 0) return -1.0;
        
        struct hostent* server = gethostbyname(host.c_str());
        if (!server) {
            close(sockfd);
            return -1.0;
        }
        
        struct sockaddr_in servAddr;
        memset(&servAddr, 0, sizeof(servAddr));
        servAddr.sin_family = AF_INET;
        memcpy(&servAddr.sin_addr.s_addr, server->h_addr, server->h_length);
        servAddr.sin_port = htons(80);
        
        auto connStart = std::chrono::steady_clock::now();
        if (connect(sockfd, (struct sockaddr*)&servAddr, sizeof(servAddr)) < 0) {
            close(sockfd);
            return -1.0;
        }
        auto connEnd = std::chrono::steady_clock::now();
        close(sockfd);
        
        return std::chrono::duration<double, std::milli>(connEnd - connStart).count();
    }
    
    // ICMP Echo Request
    struct sockaddr_in destAddr;
    memset(&destAddr, 0, sizeof(destAddr));
    destAddr.sin_family = AF_INET;
    inet_pton(AF_INET, host.c_str(), &destAddr.sin_addr);
    
    // Build ICMP packet
    char packet[64];
    struct icmphdr* icmp = (struct icmphdr*)packet;
    icmp->type = ICMP_ECHO;
    icmp->code = 0;
    icmp->un.echo.id = getpid();
    icmp->un.echo.sequence = 0;
    
    // Fill payload
    memset(packet + sizeof(struct icmphdr), 0xAA, sizeof(packet) - sizeof(struct icmphdr));
    
    // Calculate checksum
    icmp->checksum = 0;
    unsigned long sum = 0;
    unsigned short* ptr = (unsigned short*)packet;
    for (size_t i = 0; i < sizeof(packet); i += 2) {
        sum += *ptr++;
    }
    while (sum >> 16) sum = (sum & 0xFFFF) + (sum >> 16);
    icmp->checksum = ~sum;
    
    auto sendTime = std::chrono::steady_clock::now();
    
    if (sendto(sockfd, packet, sizeof(packet), 0, 
               (struct sockaddr*)&destAddr, sizeof(destAddr)) < 0) {
        close(sockfd);
        return -1.0;
    }
    
    // Receive reply
    char recvBuf[128];
    struct sockaddr_in fromAddr;
    socklen_t fromLen = sizeof(fromAddr);
    
    struct timeval tv;
    tv.tv_sec = 2;
    tv.tv_usec = 0;
    setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    
    ssize_t recvLen = recvfrom(sockfd, recvBuf, sizeof(recvBuf), 0,
                               (struct sockaddr*)&fromAddr, &fromLen);
    
    auto recvTime = std::chrono::steady_clock::now();
    close(sockfd);
    
    if (recvLen < 0) return -1.0;
    
    return std::chrono::duration<double, std::milli>(recvTime - sendTime).count();
}

void PingAnalyzer::UpdateMetrics(const PingResult& result) {
    std::lock_guard<std::mutex> lock(m_metricsMutex);
    
    m_currentMetrics.packetsSent++;
    if (result.success) {
        m_currentMetrics.packetsReceived++;
        m_currentMetrics.currentPingMs = result.rttMs;
        
        if (m_pingHistory.size() >= MAX_PING_HISTORY) {
            m_pingHistory.erase(m_pingHistory.begin());
        }
        m_pingHistory.push_back(result.rttMs);
        
        // Update min/max
        if (m_currentMetrics.minPingMs == 0 || result.rttMs < m_currentMetrics.minPingMs) {
            m_currentMetrics.minPingMs = result.rttMs;
        }
        if (result.rttMs > m_currentMetrics.maxPingMs) {
            m_currentMetrics.maxPingMs = result.rttMs;
        }
        
        // Calculate averages
        if (!m_pingHistory.empty()) {
            double sum = std::accumulate(m_pingHistory.begin(), m_pingHistory.end(), 0.0);
            m_currentMetrics.averagePingMs = sum / m_pingHistory.size();
        }
        
        CalculateJitter();
    }
    
    // Packet loss
    if (m_currentMetrics.packetsSent > 0) {
        m_currentMetrics.packetLossPercent = 
            100.0 * (1.0 - static_cast<double>(m_currentMetrics.packetsReceived) / 
                     m_currentMetrics.packetsSent);
    }
}

void PingAnalyzer::CalculateJitter() {
    if (m_pingHistory.size() < 2) {
        m_currentMetrics.jitterMs = 0.0;
        return;
    }
    
    // RFC 3550 jitter calculation: average deviation between consecutive samples
    double jitterSum = 0.0;
    for (size_t i = 1; i < m_pingHistory.size(); i++) {
        jitterSum += std::abs(m_pingHistory[i] - m_pingHistory[i-1]);
    }
    m_currentMetrics.jitterMs = jitterSum / (m_pingHistory.size() - 1);
}

} // namespace hyperboost
