#pragma once

#include <string>
#include <cstdint>
#include <fstream>

namespace hyperboost {

enum class GpuVendor {
    UNKNOWN,
    QUALCOMM_ADRENO,
    ARM_MALI,
    IMAGINE_POWERVR,
    NVIDIA_TEGRA
};

class GpuTelemetry {
public:
    GpuTelemetry();
    ~GpuTelemetry();
    
    bool Initialize();
    void Sample(int& usagePercent, int& frequencyMhz, bool& available);
    GpuVendor GetVendor() const { return m_vendor; }
    std::string GetVendorString() const;
    
private:
    bool DetectAdreno();
    bool DetectMali();
    bool DetectPowerVR();
    
    void SampleAdreno(int& usagePercent, int& frequencyMhz);
    void SampleMali(int& usagePercent, int& frequencyMhz);
    
    GpuVendor m_vendor;
    std::string m_gpuPath;
    std::ifstream m_usageStream;
    std::ifstream m_freqStream;
    std::ifstream m_clockStream;
    bool m_initialized;
};

} // namespace hyperboost
