#pragma once

#include <cstdint>
#include <fstream>
#include <string>

namespace hyperboost {

struct MemorySnapshot {
    uint64_t totalKb;
    uint64_t freeKb;
    uint64_t availableKb;
    uint64_t cachedKb;
    uint64_t activeKb;
    uint64_t inactiveKb;
    uint64_t buffersKb;
    uint64_t swapTotalKb;
    uint64_t swapFreeKb;
    uint64_t dirtyKb;
    uint64_t writebackKb;
};

class MemoryTracker {
public:
    MemoryTracker();
    ~MemoryTracker();
    
    bool Initialize();
    void Sample(uint64_t& totalKb, uint64_t& availableKb, 
                uint64_t& cachedKb, uint64_t& activeKb);
    MemorySnapshot GetDetailedSnapshot();
    
private:
    void ParseProcMeminfo();
    
    std::ifstream m_meminfoStream;
    MemorySnapshot m_snapshot;
    bool m_initialized;
};

} // namespace hyperboost
