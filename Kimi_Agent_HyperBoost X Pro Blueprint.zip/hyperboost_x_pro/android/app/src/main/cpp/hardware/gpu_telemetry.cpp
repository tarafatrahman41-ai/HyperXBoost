#include "gpu_telemetry.h"
#include <android/log.h>
#include <sys/stat.h>
#include <unistd.h>

#define LOG_TAG "GpuTelemetry"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace hyperboost {

GpuTelemetry::GpuTelemetry() 
    : m_vendor(GpuVendor::UNKNOWN), m_initialized(false) {
}

GpuTelemetry::~GpuTelemetry() {
    if (m_usageStream.is_open()) m_usageStream.close();
    if (m_freqStream.is_open()) m_freqStream.close();
    if (m_clockStream.is_open()) m_clockStream.close();
}

bool GpuTelemetry::Initialize() {
    if (DetectAdreno()) {
        m_vendor = GpuVendor::QUALCOMM_ADRENO;
        LOGI("Detected Qualcomm Adreno GPU at %s", m_gpuPath.c_str());
        m_initialized = true;
        return true;
    }
    
    if (DetectMali()) {
        m_vendor = GpuVendor::ARM_MALI;
        LOGI("Detected ARM Mali GPU at %s", m_gpuPath.c_str());
        m_initialized = true;
        return true;
    }
    
    if (DetectPowerVR()) {
        m_vendor = GpuVendor::IMAGINE_POWERVR;
        LOGI("Detected Imagination PowerVR GPU");
        m_initialized = true;
        return true;
    }
    
    LOGI("No supported GPU vendor detected - GPU metrics unavailable");
    m_initialized = false;
    return false;
}

void GpuTelemetry::Sample(int& usagePercent, int& frequencyMhz, bool& available) {
    if (!m_initialized) {
        available = false;
        usagePercent = -1;
        frequencyMhz = 0;
        return;
    }
    
    available = true;
    
    switch (m_vendor) {
        case GpuVendor::QUALCOMM_ADRENO:
            SampleAdreno(usagePercent, frequencyMhz);
            break;
        case GpuVendor::ARM_MALI:
            SampleMali(usagePercent, frequencyMhz);
            break;
        default:
            usagePercent = -1;
            frequencyMhz = 0;
            available = false;
            break;
    }
}

std::string GpuTelemetry::GetVendorString() const {
    switch (m_vendor) {
        case GpuVendor::QUALCOMM_ADRENO: return "Qualcomm Adreno";
        case GpuVendor::ARM_MALI: return "ARM Mali";
        case GpuVendor::IMAGINE_POWERVR: return "Imagination PowerVR";
        case GpuVendor::NVIDIA_TEGRA: return "NVIDIA Tegra";
        default: return "Unknown";
    }
}

bool GpuTelemetry::DetectAdreno() {
    const char* adrenoPaths[] = {
        "/sys/class/kgsl/kgsl-3d0",
        "/sys/class/misc/mali0",
        "/sys/class/gpu/gpu_0"
    };
    
    for (const auto& path : adrenoPaths) {
        struct stat st;
        if (stat(path, &st) == 0 && S_ISDIR(st.st_mode)) {
            // Verify it's actually Adreno by checking device/model
            std::string devicePath = std::string(path) + "/device_model";
            std::ifstream devFile(devicePath);
            if (devFile.is_open()) {
                std::string model;
                std::getline(devFile, model);
                devFile.close();
                if (model.find("Adreno") != std::string::npos || 
                    model.find("adreno") != std::string::npos) {
                    m_gpuPath = path;
                    
                    std::string freqPath = m_gpuPath + "/clock_mhz";
                    m_freqStream.open(freqPath);
                    
                    std::string utilPath = m_gpuPath + "/gpu_busy_percentage";
                    m_usageStream.open(utilPath);
                    
                    return true;
                }
            }
            
            // Fallback: check for Adreno-specific files
            std::string clkPath = std::string(path) + "/gpuclk";
            struct stat clkSt;
            if (stat(clkPath.c_str(), &clkSt) == 0) {
                m_gpuPath = path;
                m_clockStream.open(clkPath);
                
                std::string utilPath = m_gpuPath + "/gpu_busy_percentage";
                m_usageStream.open(utilPath);
                
                return true;
            }
        }
    }
    
    return false;
}

bool GpuTelemetry::DetectMali() {
    const char* maliPaths[] = {
        "/sys/class/misc/mali0",
        "/sys/class/mali",
        "/sys/devices/platform/mali.0"
    };
    
    for (const auto& path : maliPaths) {
        struct stat st;
        if (stat(path, &st) == 0) {
            m_gpuPath = path;
            
            std::string utilPath = m_gpuPath + "/device/utilization";
            m_usageStream.open(utilPath);
            
            std::string freqPath = m_gpuPath + "/device/clock";
            m_freqStream.open(freqPath);
            
            return true;
        }
    }
    
    return false;
}

bool GpuTelemetry::DetectPowerVR() {
    struct stat st;
    if (stat("/sys/class/misc/pvrsrvkm", &st) == 0) {
        m_gpuPath = "/sys/class/misc/pvrsrvkm";
        return true;
    }
    return false;
}

void GpuTelemetry::SampleAdreno(int& usagePercent, int& frequencyMhz) {
    usagePercent = -1;
    frequencyMhz = 0;
    
    // Read GPU busy percentage
    if (m_usageStream.is_open()) {
        m_usageStream.clear();
        m_usageStream.seekg(0);
        int rawUsage;
        if (m_usageStream >> rawUsage) {
            usagePercent = rawUsage;
        }
    }
    
    // Read frequency
    if (m_freqStream.is_open()) {
        m_freqStream.clear();
        m_freqStream.seekg(0);
        m_freqStream >> frequencyMhz;
    } else if (m_clockStream.is_open()) {
        m_clockStream.clear();
        m_clockStream.seekg(0);
        uint64_t hz;
        if (m_clockStream >> hz) {
            frequencyMhz = static_cast<int>(hz / 1000000);
        }
    }
}

void GpuTelemetry::SampleMali(int& usagePercent, int& frequencyMhz) {
    usagePercent = -1;
    frequencyMhz = 0;
    
    if (m_usageStream.is_open()) {
        m_usageStream.clear();
        m_usageStream.seekg(0);
        m_usageStream >> usagePercent;
    }
    
    if (m_freqStream.is_open()) {
        m_freqStream.clear();
        m_freqStream.seekg(0);
        uint64_t hz;
        if (m_freqStream >> hz) {
            frequencyMhz = static_cast<int>(hz / 1000000);
        }
    }
}

} // namespace hyperboost
