#include "cpu_telemetry.h"
#include <android/log.h>
#include <dirent.h>
#include <sstream>
#include <cstring>
#include <unistd.h>

#define LOG_TAG "CpuTelemetry"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace hyperboost {

CpuTelemetry::CpuTelemetry() 
    : m_coreCount(0), m_initialized(false) {
}

CpuTelemetry::~CpuTelemetry() {
    for (auto& stream : m_freqStreams) {
        if (stream.is_open()) stream.close();
    }
    if (m_procStatStream.is_open()) m_procStatStream.close();
}

bool CpuTelemetry::Initialize() {
    DIR* cpuDir = opendir("/sys/devices/system/cpu");
    if (!cpuDir) {
        LOGE("Failed to open /sys/devices/system/cpu");
        return false;
    }
    
    dirent* entry;
    while ((entry = readdir(cpuDir)) != nullptr) {
        if (strncmp(entry->d_name, "cpu", 3) == 0) {
            char* endptr;
            long id = strtol(entry->d_name + 3, &endptr, 10);
            if (*endptr == '\0' && id >= 0) {
                m_coreCount++;
            }
        }
    }
    closedir(cpuDir);
    
    if (m_coreCount == 0) {
        LOGE("No CPU cores detected");
        return false;
    }
    
    LOGI("Detected %u CPU cores", m_coreCount);
    
    m_freqStreams.resize(m_coreCount);
    m_prevCpuStats.resize(m_coreCount);
    m_coreData.resize(m_coreCount);
    
    for (uint32_t i = 0; i < m_coreCount; i++) {
        std::string freqPath = "/sys/devices/system/cpu/cpu" + std::to_string(i) + "/cpufreq/scaling_cur_freq";
        m_freqStreams[i].open(freqPath);
        if (!m_freqStreams[i].is_open()) {
            LOGI(" scaling_cur_freq unavailable for core %u, trying cpuinfo_cur_freq", i);
            freqPath = "/sys/devices/system/cpu/cpu" + std::to_string(i) + "/cpufreq/cpuinfo_cur_freq";
            m_freqStreams[i].open(freqPath);
        }
        
        // Read max/min frequencies
        std::string maxPath = "/sys/devices/system/cpu/cpu" + std::to_string(i) + "/cpufreq/cpuinfo_max_freq";
        std::ifstream maxFile(maxPath);
        if (maxFile.is_open()) {
            maxFile >> m_coreData[i].maxFrequencyKhz;
            maxFile.close();
        }
        
        std::string minPath = "/sys/devices/system/cpu/cpu" + std::to_string(i) + "/cpufreq/cpuinfo_min_freq";
        std::ifstream minFile(minPath);
        if (minFile.is_open()) {
            minFile >> m_coreData[i].minFrequencyKhz;
            minFile.close();
        }
        
        m_coreData[i].coreId = i;
        m_prevCpuStats[i].fill(0);
    }
    
    m_procStatStream.open("/proc/stat");
    
    // Initial stat read
    ParseProcStat();
    
    m_initialized = true;
    return true;
}

void CpuTelemetry::Sample(std::vector<CpuCoreData>& cores, double& totalLoadPercent) {
    if (!m_initialized) {
        totalLoadPercent = -1.0;
        return;
    }
    
    ReadCoreFrequencies();
    
    std::vector<std::array<uint64_t, 10>> currStats = m_prevCpuStats;
    
    m_procStatStream.clear();
    m_procStatStream.seekg(0);
    
    std::string line;
    std::getline(m_procStatStream, line); // Skip total line
    
    uint32_t coreIdx = 0;
    while (std::getline(m_procStatStream, line) && coreIdx < m_coreCount) {
        if (strncmp(line.c_str(), "cpu", 3) != 0 || !isdigit(line[3])) continue;
        
        std::istringstream iss(line);
        std::string label;
        iss >> label;
        
        for (int j = 0; j < 10; j++) {
            iss >> currStats[coreIdx][j];
        }
        coreIdx++;
    }
    
    // Calculate per-core and total load
    double totalLoad = 0.0;
    uint32_t activeCores = 0;
    
    for (uint32_t i = 0; i < m_coreCount; i++) {
        double load = CalculateLoad(m_prevCpuStats[i], currStats[i]);
        m_coreData[i].online = (load >= 0);
        if (m_coreData[i].online) {
            totalLoad += load;
            activeCores++;
        }
    }
    
    totalLoadPercent = activeCores > 0 ? (totalLoad / activeCores) : 0.0;
    m_prevCpuStats = std::move(currStats);
    cores = m_coreData;
}

std::vector<uint64_t> CpuTelemetry::GetCoreFrequencies() const {
    std::vector<uint64_t> freqs(m_coreCount);
    for (uint32_t i = 0; i < m_coreCount; i++) {
        freqs[i] = m_coreData[i].currentFrequencyKhz;
    }
    return freqs;
}

void CpuTelemetry::ReadCoreFrequencies() {
    for (uint32_t i = 0; i < m_coreCount; i++) {
        if (m_freqStreams[i].is_open()) {
            m_freqStreams[i].clear();
            m_freqStreams[i].seekg(0);
            m_freqStreams[i] >> m_coreData[i].currentFrequencyKhz;
        }
    }
}

double CpuTelemetry::CalculateLoad(const std::array<uint64_t, 10>& prev, 
                                    const std::array<uint64_t, 10>& curr) {
    uint64_t prevIdle = prev[3] + prev[4];
    uint64_t currIdle = curr[3] + curr[4];
    
    uint64_t prevTotal = 0, currTotal = 0;
    for (int i = 0; i < 10; i++) {
        prevTotal += prev[i];
        currTotal += curr[i];
    }
    
    uint64_t totalDelta = currTotal - prevTotal;
    uint64_t idleDelta = currIdle - prevIdle;
    
    if (totalDelta == 0) return 0.0;
    
    return 100.0 * (1.0 - static_cast<double>(idleDelta) / static_cast<double>(totalDelta));
}

} // namespace hyperboost
