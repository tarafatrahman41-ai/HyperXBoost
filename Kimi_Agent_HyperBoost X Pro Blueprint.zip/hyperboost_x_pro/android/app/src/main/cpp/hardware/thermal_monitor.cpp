#include "thermal_monitor.h"
#include <android/log.h>
#include <dirent.h>
#include <cstring>
#include <sstream>
#include <algorithm>

#define LOG_TAG "ThermalMonitor"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace hyperboost {

ThermalMonitor::ThermalMonitor() 
    : m_initialized(false), m_throttling(false) {
}

ThermalMonitor::~ThermalMonitor() {
}

bool ThermalMonitor::Initialize() {
    DiscoverZones();
    m_initialized = !m_zones.empty();
    if (m_initialized) {
        LOGI("Discovered %zu thermal zones", m_zones.size());
    }
    return m_initialized;
}

void ThermalMonitor::Sample(std::vector<ThermalZone>& zones, bool& throttling) {
    if (!m_initialized) {
        throttling = false;
        return;
    }
    
    for (size_t i = 0; i < m_zones.size(); i++) {
        ReadZoneTemperature(m_zones[i]);
    }
    
    m_throttling = DetectThrottling();
    throttling = m_throttling;
    zones = m_zones;
}

double ThermalMonitor::GetZoneTemperature(int index) const {
    if (index < 0 || index >= static_cast<int>(m_zones.size())) return 0.0;
    return m_zones[index].temperatureMillidegrees / 1000.0;
}

std::string ThermalMonitor::GetZoneName(int index) const {
    if (index < 0 || index >= static_cast<int>(m_zones.size())) return "Invalid";
    return m_zones[index].name;
}

void ThermalMonitor::DiscoverZones() {
    DIR* dir = opendir(THERMAL_ROOT);
    if (!dir) {
        LOGE("Failed to open %s", THERMAL_ROOT);
        return;
    }
    
    dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        if (strncmp(entry->d_name, "thermal_zone", 12) != 0) continue;
        
        char* endptr;
        long id = strtol(entry->d_name + 12, &endptr, 10);
        if (*endptr != '\0') continue;
        
        ThermalZone zone;
        zone.id = static_cast<uint32_t>(id);
        zone.critical = false;
        zone.temperatureMillidegrees = 0;
        zone.tripPoint0 = 0;
        
        std::string basePath = std::string(THERMAL_ROOT) + "/" + entry->d_name;
        
        // Read zone type
        std::ifstream typeFile(basePath + "/type");
        if (typeFile.is_open()) {
            std::getline(typeFile, zone.type);
            typeFile.close();
        }
        
        // Generate readable name
        if (!zone.type.empty()) {
            zone.name = zone.type + "_" + std::to_string(zone.id);
        } else {
            zone.name = "Zone_" + std::to_string(zone.id);
        }
        
        // Read trip point
        std::ifstream tripFile(basePath + "/trip_point_0_temp");
        if (tripFile.is_open()) {
            tripFile >> zone.tripPoint0;
            tripFile.close();
        }
        
        m_zones.push_back(zone);
        
        // Open persistent temp stream
        std::string tempPath = basePath + "/temp";
        auto stream = std::make_unique<std::ifstream>(tempPath);
        m_tempStreams.push_back(std::move(stream));
    }
    
    closedir(dir);
}

void ThermalMonitor::ReadZoneTemperature(ThermalZone& zone) {
    size_t idx = zone.id;
    if (idx >= m_tempStreams.size() || !m_tempStreams[idx] || !m_tempStreams[idx]->is_open()) {
        return;
    }
    
    m_tempStreams[idx]->clear();
    m_tempStreams[idx]->seekg(0);
    *m_tempStreams[idx] >> zone.temperatureMillidegrees;
    
    // Check if critical
    if (zone.tripPoint0 > 0 && zone.temperatureMillidegrees >= zone.tripPoint0) {
        zone.critical = true;
    }
}

bool ThermalMonitor::DetectThrottling() {
    // Throttling detection: correlate temperature with frequency reduction
    // This is a simplified check - real throttling detection requires CPU/GPU correlation
    
    int criticalZones = 0;
    for (const auto& zone : m_zones) {
        // CPU thermal zones typically throttle above 85°C
        if ((zone.type.find("cpu") != std::string::npos || 
             zone.type.find("CPU") != std::string::npos) &&
            zone.temperatureMillidegrees > 85000) {
            criticalZones++;
        }
        // GPU thermal zones typically throttle above 80°C
        if ((zone.type.find("gpu") != std::string::npos || 
             zone.type.find("GPU") != std::string::npos) &&
            zone.temperatureMillidegrees > 80000) {
            criticalZones++;
        }
    }
    
    return criticalZones >= 2;
}

} // namespace hyperboost
