#pragma once

#include <vector>
#include <string>
#include <cstdint>
#include <fstream>
#include <memory>

namespace hyperboost {

struct ThermalZone {
    uint32_t id;
    std::string name;
    std::string type;
    int32_t temperatureMillidegrees;
    int32_t tripPoint0;
    bool critical;
};

class ThermalMonitor {
public:
    ThermalMonitor();
    ~ThermalMonitor();
    
    bool Initialize();
    void Sample(std::vector<ThermalZone>& zones, bool& throttling);
    
    int GetZoneCount() const { return static_cast<int>(m_zones.size()); }
    double GetZoneTemperature(int index) const;
    std::string GetZoneName(int index) const;
    
    bool IsThrottling() const { return m_throttling; }
    
private:
    void DiscoverZones();
    void ReadZoneTemperature(ThermalZone& zone);
    bool DetectThrottling();
    
    std::vector<ThermalZone> m_zones;
    std::vector<std::unique_ptr<std::ifstream>> m_tempStreams;
    bool m_initialized;
    bool m_throttling;
    
    static constexpr const char* THERMAL_ROOT = "/sys/class/thermal";
};

} // namespace hyperboost
