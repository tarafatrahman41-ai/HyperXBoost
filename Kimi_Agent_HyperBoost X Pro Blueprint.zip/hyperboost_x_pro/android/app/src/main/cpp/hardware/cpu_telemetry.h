#pragma once

#include <vector>
#include <string>
#include <cstdint>
#include <fstream>
#include <array>

namespace hyperboost {

struct CpuCoreData {
    uint32_t coreId;
    uint32_t currentFrequencyKhz;
    uint32_t maxFrequencyKhz;
    uint32_t minFrequencyKhz;
    bool online;
};

class CpuTelemetry {
public:
    CpuTelemetry();
    ~CpuTelemetry();
    
    bool Initialize();
    void Sample(std::vector<CpuCoreData>& cores, double& totalLoadPercent);
    std::vector<uint64_t> GetCoreFrequencies() const;
    uint32_t GetCoreCount() const { return m_coreCount; }
    
private:
    void ParseProcStat();
    void ReadCoreFrequencies();
    double CalculateLoad(const std::array<uint64_t, 10>& prev, const std::array<uint64_t, 10>& curr);
    
    uint32_t m_coreCount;
    std::vector<std::ifstream> m_freqStreams;
    std::vector<std::array<uint64_t, 10>> m_prevCpuStats;
    std::vector<CpuCoreData> m_coreData;
    std::ifstream m_procStatStream;
    bool m_initialized;
};

} // namespace hyperboost
