#include "memory_tracker.h"
#include <android/log.h>
#include <sstream>
#include <cstring>

#define LOG_TAG "MemoryTracker"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace hyperboost {

MemoryTracker::MemoryTracker() : m_initialized(false) {
    m_snapshot = {};
}

MemoryTracker::~MemoryTracker() {
    if (m_meminfoStream.is_open()) m_meminfoStream.close();
}

bool MemoryTracker::Initialize() {
    m_meminfoStream.open("/proc/meminfo");
    if (!m_meminfoStream.is_open()) {
        LOGE("Failed to open /proc/meminfo");
        return false;
    }
    LOGI("Memory tracker initialized");
    m_initialized = true;
    return true;
}

void MemoryTracker::Sample(uint64_t& totalKb, uint64_t& availableKb, 
                           uint64_t& cachedKb, uint64_t& activeKb) {
    if (!m_initialized) {
        totalKb = 0;
        availableKb = 0;
        cachedKb = 0;
        activeKb = 0;
        return;
    }
    
    ParseProcMeminfo();
    
    totalKb = m_snapshot.totalKb;
    availableKb = m_snapshot.availableKb;
    cachedKb = m_snapshot.cachedKb;
    activeKb = m_snapshot.activeKb;
}

MemorySnapshot MemoryTracker::GetDetailedSnapshot() {
    ParseProcMeminfo();
    return m_snapshot;
}

void MemoryTracker::ParseProcMeminfo() {
    m_meminfoStream.clear();
    m_meminfoStream.seekg(0);
    
    std::string line;
    while (std::getline(m_meminfoStream, line)) {
        std::istringstream iss(line);
        std::string key;
        uint64_t value;
        std::string unit;
        
        iss >> key >> value >> unit;
        
        if (key == "MemTotal:") m_snapshot.totalKb = value;
        else if (key == "MemFree:") m_snapshot.freeKb = value;
        else if (key == "MemAvailable:") m_snapshot.availableKb = value;
        else if (key == "Cached:") m_snapshot.cachedKb = value;
        else if (key == "Active:") m_snapshot.activeKb = value;
        else if (key == "Inactive:") m_snapshot.inactiveKb = value;
        else if (key == "Buffers:") m_snapshot.buffersKb = value;
        else if (key == "SwapTotal:") m_snapshot.swapTotalKb = value;
        else if (key == "SwapFree:") m_snapshot.swapFreeKb = value;
        else if (key == "Dirty:") m_snapshot.dirtyKb = value;
        else if (key == "Writeback:") m_snapshot.writebackKb = value;
    }
}

} // namespace hyperboost
