#pragma once

#include <cstdint>
#include <vector>
#include <deque>
#include <chrono>
#include <mutex>
#include <atomic>

namespace hyperboost {

struct FrameMetrics {
    double currentFps;
    double averageFps;
    double onePercentLow;
    double pointOnePercentLow;
    uint32_t stutterCount;
    uint32_t totalFrames;
    double frameVariance;
    double lastFrameTimeMs;
    double targetFrameTimeMs;
    bool frameDropped;
};

class FramePacingEngine {
public:
    FramePacingEngine();
    ~FramePacingEngine();
    
    void RecordFrameTimestamp(int64_t timestampNanos);
    void SetTargetRefreshRate(int hz);
    FrameMetrics ComputeMetrics();
    void Reset();
    
private:
    void CalculatePercentileLows(FrameMetrics& metrics);
    void DetectStutters(FrameMetrics& metrics);
    
    std::deque<double> m_frameTimes; // in milliseconds
    std::vector<double> m_sortedFrameTimes;
    
    std::mutex m_mutex;
    
    std::atomic<int64_t> m_lastTimestamp{0};
    std::atomic<int> m_targetHz{60};
    std::atomic<uint32_t> m_totalFrames{0};
    std::atomic<uint32_t> m_stutterCount{0};
    
    static constexpr size_t MAX_FRAME_HISTORY = 3600; // 1 minute at 60fps
    static constexpr double STUTTER_THRESHOLD_MULTIPLIER = 1.5;
};

} // namespace hyperboost
