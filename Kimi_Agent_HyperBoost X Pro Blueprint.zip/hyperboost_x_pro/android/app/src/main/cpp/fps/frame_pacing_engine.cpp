#include "frame_pacing_engine.h"
#include <android/log.h>
#include <algorithm>
#include <numeric>
#include <cmath>

#define LOG_TAG "FramePacing"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

namespace hyperboost {

FramePacingEngine::FramePacingEngine() {
    m_frameTimes.reserve(MAX_FRAME_HISTORY);
    m_sortedFrameTimes.reserve(MAX_FRAME_HISTORY);
}

FramePacingEngine::~FramePacingEngine() {
}

void FramePacingEngine::RecordFrameTimestamp(int64_t timestampNanos) {
    int64_t last = m_lastTimestamp.load();
    if (last == 0) {
        m_lastTimestamp.store(timestampNanos);
        return;
    }
    
    double frameTimeMs = static_cast<double>(timestampNanos - last) / 1'000'000.0;
    m_lastTimestamp.store(timestampNanos);
    
    std::lock_guard<std::mutex> lock(m_mutex);
    
    if (m_frameTimes.size() >= MAX_FRAME_HISTORY) {
        m_frameTimes.pop_front();
    }
    m_frameTimes.push_back(frameTimeMs);
    m_totalFrames++;
}

void FramePacingEngine::SetTargetRefreshRate(int hz) {
    m_targetHz.store(hz);
}

FrameMetrics FramePacingEngine::ComputeMetrics() {
    FrameMetrics metrics = {};
    metrics.targetFrameTimeMs = 1000.0 / m_targetHz.load();
    
    std::lock_guard<std::mutex> lock(m_mutex);
    
    if (m_frameTimes.empty()) {
        metrics.currentFps = 0.0;
        metrics.averageFps = 0.0;
        return metrics;
    }
    
    // Current FPS from last frame
    double lastFt = m_frameTimes.back();
    metrics.lastFrameTimeMs = lastFt;
    metrics.currentFps = lastFt > 0 ? 1000.0 / lastFt : 0.0;
    
    // Average FPS over window
    double totalTime = std::accumulate(m_frameTimes.begin(), m_frameTimes.end(), 0.0);
    metrics.averageFps = m_frameTimes.size() > 0 ? 
        (1000.0 * m_frameTimes.size()) / totalTime : 0.0;
    
    // Copy and sort for percentile calculations
    m_sortedFrameTimes.assign(m_frameTimes.begin(), m_frameTimes.end());
    std::sort(m_sortedFrameTimes.begin(), m_sortedFrameTimes.end(), std::greater<double>());
    
    CalculatePercentileLows(metrics);
    DetectStutters(metrics);
    
    metrics.totalFrames = m_totalFrames.load();
    metrics.stutterCount = m_stutterCount.load();
    
    // Frame variance
    if (m_frameTimes.size() >= 2) {
        double mean = totalTime / m_frameTimes.size();
        double variance = 0.0;
        for (double ft : m_frameTimes) {
            variance += (ft - mean) * (ft - mean);
        }
        variance /= m_frameTimes.size();
        metrics.frameVariance = variance;
    }
    
    return metrics;
}

void FramePacingEngine::Reset() {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_frameTimes.clear();
    m_sortedFrameTimes.clear();
    m_totalFrames.store(0);
    m_stutterCount.store(0);
    m_lastTimestamp.store(0);
}

void FramePacingEngine::CalculatePercentileLows(FrameMetrics& metrics) {
    if (m_sortedFrameTimes.empty()) return;
    
    // 1% Low: Average of worst 1% frame times
    size_t onePercentCount = std::max(size_t(1), m_sortedFrameTimes.size() / 100);
    double onePercentSum = 0.0;
    for (size_t i = 0; i < onePercentCount && i < m_sortedFrameTimes.size(); i++) {
        onePercentSum += m_sortedFrameTimes[i];
    }
    metrics.onePercentLow = 1000.0 / (onePercentSum / onePercentCount);
    
    // 0.1% Low: Average of worst 0.1% frame times
    size_t pointOneCount = std::max(size_t(1), m_sortedFrameTimes.size() / 1000);
    double pointOneSum = 0.0;
    for (size_t i = 0; i < pointOneCount && i < m_sortedFrameTimes.size(); i++) {
        pointOneSum += m_sortedFrameTimes[i];
    }
    metrics.pointOnePercentLow = 1000.0 / (pointOneSum / pointOneCount);
}

void FramePacingEngine::DetectStutters(FrameMetrics& metrics) {
    double threshold = metrics.targetFrameTimeMs * STUTTER_THRESHOLD_MULTIPLIER;
    
    uint32_t stutters = 0;
    for (double ft : m_frameTimes) {
        if (ft > threshold) {
            stutters++;
        }
    }
    
    // Only count new stutters since last check
    uint32_t prevStutters = m_stutterCount.load();
    uint32_t newStutters = stutters; // Simplified - in production would track properly
    m_stutterCount.store(newStutters);
    
    metrics.frameDropped = !m_frameTimes.empty() && m_frameTimes.back() > threshold;
}

} // namespace hyperboost
