#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <chrono>
#include <thread>
#include <atomic>
#include <memory>

#include "hardware/cpu_telemetry.h"
#include "hardware/gpu_telemetry.h"
#include "hardware/thermal_monitor.h"
#include "hardware/memory_tracker.h"
#include "fps/frame_pacing_engine.h"
#include "network/ping_analyzer.h"
#include "utils/ring_buffer.h"

#define LOG_TAG "HyperBoostNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)

using namespace hyperboost;

static std::unique_ptr<CpuTelemetry> g_cpuTelemetry;
static std::unique_ptr<GpuTelemetry> g_gpuTelemetry;
static std::unique_ptr<ThermalMonitor> g_thermalMonitor;
static std::unique_ptr<MemoryTracker> g_memoryTracker;
static std::unique_ptr<FramePacingEngine> g_frameEngine;
static std::unique_ptr<PingAnalyzer> g_pingAnalyzer;
static std::unique_ptr<RingBuffer<TelemetryFrame>> g_ringBuffer;

static std::atomic<bool> g_pollingActive{false};
static std::thread g_pollingThread;
static jlong g_pollingIntervalMs = 500;

extern "C" {

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
    LOGI("HyperBoost Native Library Loaded - v1.0.0");
    g_cpuTelemetry = std::make_unique<CpuTelemetry>();
    g_gpuTelemetry = std::make_unique<GpuTelemetry>();
    g_thermalMonitor = std::make_unique<ThermalMonitor>();
    g_memoryTracker = std::make_unique<MemoryTracker>();
    g_frameEngine = std::make_unique<FramePacingEngine>();
    g_pingAnalyzer = std::make_unique<PingAnalyzer>();
    g_ringBuffer = std::make_unique<RingBuffer<TelemetryFrame>>(3600); // 1 hour at 1Hz
    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
Java_com_hyperboost_xpro_jni_NativeBridge_initializeNative(JNIEnv* env, jclass clazz) {
    LOGI("Initializing native telemetry subsystems");
    
    if (!g_cpuTelemetry->Initialize()) {
        LOGE("CPU telemetry initialization failed - some metrics unavailable");
    }
    if (!g_gpuTelemetry->Initialize()) {
        LOGI("GPU telemetry initialization failed - vendor may not be supported");
    }
    if (!g_thermalMonitor->Initialize()) {
        LOGE("Thermal monitor initialization failed");
    }
    if (!g_memoryTracker->Initialize()) {
        LOGE("Memory tracker initialization failed");
    }
    
    LOGI("Native telemetry initialization complete");
}

JNIEXPORT void JNICALL
Java_com_hyperboost_xpro_jni_NativeBridge_startPolling(JNIEnv* env, jclass clazz, jlong intervalMs) {
    if (g_pollingActive.exchange(true)) {
        LOGW("Polling already active, ignoring start request");
        return;
    }
    
    g_pollingIntervalMs = intervalMs;
    
    g_pollingThread = std::thread([]() {
        LOGI("Hardware polling thread started - interval: %ld ms", g_pollingIntervalMs.load());
        
        struct sched_param param;
        param.sched_priority = sched_get_priority_min(SCHED_FIFO);
        pthread_setschedparam(pthread_self(), SCHED_FIFO, &param);
        
        pthread_setname_np(pthread_self(), "hb_poll");
        
        while (g_pollingActive.load()) {
            auto start = std::chrono::steady_clock::now();
            
            TelemetryFrame frame;
            frame.timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::steady_clock::now().time_since_epoch()).count();
            
            // CPU telemetry
            g_cpuTelemetry->Sample(frame.cpuCores, frame.cpuLoadPercent);
            
            // GPU telemetry
            g_gpuTelemetry->Sample(frame.gpuCoreUsage, frame.gpuFrequencyMhz, frame.gpuAvailable);
            
            // Thermal
            g_thermalMonitor->Sample(frame.thermalZones, frame.thermalThrottling);
            
            // Memory
            g_memoryTracker->Sample(frame.memoryTotalKb, frame.memoryAvailableKb, 
                                     frame.memoryCachedKb, frame.memoryActiveKb);
            
            // Push to ring buffer
            g_ringBuffer->Push(frame);
            
            auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::steady_clock::now() - start).count();
            
            jlong sleepMs = g_pollingIntervalMs.load() - elapsed;
            if (sleepMs > 0) {
                std::this_thread::sleep_for(std::chrono::milliseconds(sleepMs));
            }
        }
        
        LOGI("Hardware polling thread terminated");
    });
}

JNIEXPORT void JNICALL
Java_com_hyperboost_xpro_jni_NativeBridge_stopPolling(JNIEnv* env, jclass clazz) {
    g_pollingActive.store(false);
    if (g_pollingThread.joinable()) {
        g_pollingThread.join();
    }
    LOGI("Native polling stopped");
}

JNIEXPORT jobject JNICALL
Java_com_hyperboost_xpro_jni_NativeBridge_getLatestTelemetry(JNIEnv* env, jclass clazz) {
    auto frame = g_ringBuffer->Latest();
    if (!frame) return nullptr;
    
    jclass telemetryClass = env->FindClass("com/hyperboost/xpro/jni/TelemetryData");
    jmethodID constructor = env->GetMethodID(telemetryClass, "<init>", "()V");
    jobject telemetry = env->NewObject(telemetryClass, constructor);
    
    // Set timestamp
    jfieldID tsField = env->GetFieldID(telemetryClass, "timestamp", "J");
    env->SetLongField(telemetry, tsField, frame->timestamp);
    
    // CPU data
    jfieldID cpuLoadField = env->GetFieldID(telemetryClass, "cpuLoadPercent", "D");
    env->SetDoubleField(telemetry, cpuLoadField, frame->cpuLoadPercent);
    
    // GPU data
    jfieldID gpuUsageField = env->GetFieldID(telemetryClass, "gpuUsagePercent", "I");
    env->SetIntField(telemetry, gpuUsageField, frame->gpuCoreUsage);
    
    jfieldID gpuFreqField = env->GetFieldID(telemetryClass, "gpuFrequencyMhz", "I");
    env->SetIntField(telemetry, gpuFreqField, frame->gpuFrequencyMhz);
    
    jfieldID gpuAvailField = env->GetFieldID(telemetryClass, "gpuAvailable", "Z");
    env->SetBooleanField(telemetry, gpuAvailField, frame->gpuAvailable);
    
    // Memory data
    jfieldID memTotalField = env->GetFieldID(telemetryClass, "memoryTotalKb", "J");
    env->SetLongField(telemetry, memTotalField, frame->memoryTotalKb);
    
    jfieldID memAvailField = env->GetFieldID(telemetryClass, "memoryAvailableKb", "J");
    env->SetLongField(telemetry, memAvailField, frame->memoryAvailableKb);
    
    // Thermal
    jfieldID throttlingField = env->GetFieldID(telemetryClass, "thermalThrottling", "Z");
    env->SetBooleanField(telemetry, throttlingField, frame->thermalThrottling);
    
    return telemetry;
}

JNIEXPORT jobjectArray JNICALL
Java_com_hyperboost_xpro_jni_NativeBridge_getCpuCoreFrequencies(JNIEnv* env, jclass clazz) {
    auto freqs = g_cpuTelemetry->GetCoreFrequencies();
    
    jclass longClass = env->FindClass("java/lang/Long");
    jobjectArray result = env->NewObjectArray(freqs.size(), longClass, nullptr);
    jmethodID longCtor = env->GetMethodID(longClass, "<init>", "(J)V");
    
    for (size_t i = 0; i < freqs.size(); i++) {
        jobject val = env->NewObject(longClass, longCtor, static_cast<jlong>(freqs[i]));
        env->SetObjectArrayElement(result, i, val);
        env->DeleteLocalRef(val);
    }
    
    return result;
}

JNIEXPORT jint JNICALL
Java_com_hyperboost_xpro_jni_NativeBridge_getThermalZoneCount(JNIEnv* env, jclass clazz) {
    return g_thermalMonitor->GetZoneCount();
}

JNIEXPORT jdouble JNICALL
Java_com_hyperboost_xpro_jni_NativeBridge_getThermalZoneTemp(JNIEnv* env, jclass clazz, jint zoneIndex) {
    return g_thermalMonitor->GetZoneTemperature(zoneIndex);
}

JNIEXPORT jstring JNICALL
Java_com_hyperboost_xpro_jni_NativeBridge_getThermalZoneName(JNIEnv* env, jclass clazz, jint zoneIndex) {
    std::string name = g_thermalMonitor->GetZoneName(zoneIndex);
    return env->NewStringUTF(name.c_str());
}

JNIEXPORT void JNICALL
Java_com_hyperboost_xpro_jni_NativeBridge_nativeDestroy(JNIEnv* env, jclass clazz) {
    g_pollingActive.store(false);
    if (g_pollingThread.joinable()) {
        g_pollingThread.join();
    }
    LOGI("Native resources destroyed");
}

} // extern "C"
