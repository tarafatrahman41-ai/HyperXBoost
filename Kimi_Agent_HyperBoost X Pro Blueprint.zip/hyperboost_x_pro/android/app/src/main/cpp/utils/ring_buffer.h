#pragma once

#include <vector>
#include <mutex>
#include <optional>
#include <cstddef>
#include <atomic>

namespace hyperboost {

typedef unsigned long ulong;

struct CpuCoreData;
struct ThermalZone;

struct TelemetryFrame {
    int64_t timestamp;
    
    // CPU
    std::vector<CpuCoreData> cpuCores;
    double cpuLoadPercent;
    
    // GPU
    int gpuCoreUsage;
    int gpuFrequencyMhz;
    bool gpuAvailable;
    
    // Memory
    uint64_t memoryTotalKb;
    uint64_t memoryAvailableKb;
    uint64_t memoryCachedKb;
    uint64_t memoryActiveKb;
    
    // Thermal
    std::vector<ThermalZone> thermalZones;
    bool thermalThrottling;
};

template<typename T>
class RingBuffer {
public:
    explicit RingBuffer(size_t capacity) 
        : m_buffer(capacity), m_capacity(capacity), 
          m_head(0), m_tail(0), m_size(0) {}
    
    void Push(const T& item) {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_buffer[m_head] = item;
        m_head = (m_head + 1) % m_capacity;
        if (m_size < m_capacity) {
            m_size++;
        } else {
            m_tail = (m_tail + 1) % m_capacity;
        }
    }
    
    std::optional<T> Latest() const {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (m_size == 0) return std::nullopt;
        size_t idx = (m_head + m_capacity - 1) % m_capacity;
        return m_buffer[idx];
    }
    
    std::vector<T> GetRange(size_t count) const {
        std::lock_guard<std::mutex> lock(m_mutex);
        std::vector<T> result;
        result.reserve(std::min(count, m_size));
        
        size_t idx = (m_head + m_capacity - 1) % m_capacity;
        for (size_t i = 0; i < count && i < m_size; i++) {
            result.push_back(m_buffer[idx]);
            idx = (idx + m_capacity - 1) % m_capacity;
        }
        return result;
    }
    
    size_t Size() const { return m_size; }
    bool Empty() const { return m_size == 0; }
    void Clear() {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_head = m_tail = m_size = 0;
    }
    
private:
    std::vector<T> m_buffer;
    size_t m_capacity;
    size_t m_head;
    size_t m_tail;
    size_t m_size;
    mutable std::mutex m_mutex;
};

} // namespace hyperboost
