#pragma once

#include <string>
#include <cstdint>
#include <vector>
#include <dirent.h>
#include <sys/stat.h>

namespace hyperboost {
namespace utils {

std::string ReadFileString(const std::string& path);
uint64_t ReadFileUint64(const std::string& path);
int64_t ReadFileInt64(const std::string& path);
std::vector<std::string> ReadDirectory(const std::string& path);
bool FileExists(const std::string& path);

} // namespace utils
} // namespace hyperboost
