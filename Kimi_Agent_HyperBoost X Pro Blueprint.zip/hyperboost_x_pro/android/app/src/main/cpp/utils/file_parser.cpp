#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <android/log.h>

#define LOG_TAG "FileParser"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

namespace hyperboost {
namespace utils {

std::string ReadFileString(const std::string& path) {
    std::ifstream file(path);
    if (!file.is_open()) return "";
    std::stringstream buffer;
    buffer << file.rdbuf();
    return buffer.str();
}

uint64_t ReadFileUint64(const std::string& path) {
    std::ifstream file(path);
    if (!file.is_open()) return 0;
    uint64_t value;
    file >> value;
    return value;
}

int64_t ReadFileInt64(const std::string& path) {
    std::ifstream file(path);
    if (!file.is_open()) return -1;
    int64_t value;
    file >> value;
    return value;
}

std::vector<std::string> ReadDirectory(const std::string& path) {
    std::vector<std::string> entries;
    DIR* dir = opendir(path.c_str());
    if (!dir) return entries;
    
    dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        if (strcmp(entry->d_name, ".") != 0 && strcmp(entry->d_name, "..") != 0) {
            entries.push_back(entry->d_name);
        }
    }
    closedir(dir);
    return entries;
}

bool FileExists(const std::string& path) {
    struct stat st;
    return stat(path.c_str(), &st) == 0;
}

} // namespace utils
} // namespace hyperboost
