# HyperBoost X Pro ProGuard Rules
# Keep native methods and JNI classes
-keepclasseswithmembernames class * {
    native <methods>;
}

# Keep JNI bridge classes
-keep class com.hyperboost.xpro.jni.** { *; }
-keepclassmembers class com.hyperboost.xpro.jni.** { *; }

# Keep service classes for Android manifest
-keep class com.hyperboost.xpro.service.** { *; }
-keep class com.hyperboost.xpro.overlay.** { *; }
-keep class com.hyperboost.xpro.recorder.** { *; }
-keep class com.hyperboost.xpro.game.** { *; }
-keep class com.hyperboost.xpro.MainActivity { *; }
-keep class com.hyperboost.xpro.HyperBoostApplication { *; }

# Keep Parcelable implementations
-keepclassmembers class * implements android.os.Parcelable {
    static ** CREATOR;
}

# Keep Flutter plugins
-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.** { *; }
-keep class io.flutter.util.** { *; }
-keep class io.flutter.view.** { *; }
-keep class io.flutter.** { *; }
-keep class io.flutter.plugins.** { *; }

# Keep Kotlin coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembers class kotlinx.coroutines.** {
    volatile <fields>;
}

# Remove logging in release
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
    public static int i(...);
    public static int w(...);
    public static int e(...);
}

# Keep enum values
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# Optimization
-optimizations !code/simplification/arithmetic,!code/simplification/cast,!field/*,!class/merging/*
-optimizationpasses 5
-allowaccessmodification
-dontpreverify
